() => {
            const result = {textInputs: [], selectBoxes: [], radios: [], passage: '', allQuestions: [], debugPassage: ''};

            // 1. 提取阅读文章
            const passageEls = document.querySelectorAll(
                '.reading-passage, .passage, article, [class*="passage"], [class*="reading"], .question-stem, [class*="article"], [class*="text-content"], [class*="reading-content"], [class*="content-body"], [class*="exam-content"], [class*="material"], [class*="articleContent"], [class*="readArea"]'
            );
            let passageText = '';
            passageEls.forEach(el => {
                const txt = el.innerText.trim();
                if (txt.length > 100) passageText += txt + '\\n';
            });
            // 如果上面没找到，尝试从 Part 容器中提取
            if (passageText.length < 200) {
                const parts = document.querySelectorAll('.partDiv, [class*="part"], [class*="Part"]');
                parts.forEach(p => {
                    const allText = p.innerText.trim();
                    // 找最长的文本块作为 passage
                    if (allText.length > passageText.length && allText.length > 300) {
                        passageText = allText;
                    }
                });
            }
            result.passage = passageText.substring(0, 5000);
            result.debugPassage = passageText.length > 0 ? passageText.substring(0, 200) : '(empty)';

            // 2. 扫描填空题 — 全面扫描所有文本输入元素
            // 2a. 扫描当前 Part 的输入框
            // 找到当前可见的 partDiv
            var curPartDiv = null;
            if (typeof curPartNum !== 'undefined' && curPartNum > 0) {
                curPartDiv = document.getElementById('part' + curPartNum);
            }
            if (!curPartDiv) {
                document.querySelectorAll('.partDiv').forEach(d => {
                    if (d.style.display !== 'none') curPartDiv = d;
                });
            }
            const scanRoot = curPartDiv || document;
            const allInputs = scanRoot.querySelectorAll('input, textarea');
            const seenQnums = new Set();
            allInputs.forEach((el) => {
                if (el.type === 'hidden' || el.type === 'radio' || el.type === 'checkbox' ||
                    el.type === 'submit' || el.type === 'button' || el.type === 'file' ||
                    el.type === 'select-one' || el.type === 'select-multiple') return;
                if (el.offsetParent === null) return;  // 不可见
                const navParent = el.closest('nav, header, footer, .navbar, .search, .login, .header, .footer, .sidebar, .menu, .toolbar');
                if (navParent) return;
                const qnum = el.dataset.qnum ? parseInt(el.dataset.qnum) : 0;
                if (qnum > 0 && seenQnums.has(qnum)) return;  // 去重
                if (qnum > 0) seenQnums.add(qnum);
                const qtype = el.dataset.qtype || '';
                let qText = '';
                // 优先用 question_{qnum} 容器获取题目
                if (qnum > 0) {
                    const qContainer = document.getElementById('question_' + qnum);
                    if (qContainer) {
                        const clone = qContainer.cloneNode(true);
                        clone.querySelectorAll('input, textarea, select, button').forEach(e => e.remove());
                        qText = clone.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                    }
                }
                // 兜底1：向上找最近的题目容器
                if (!qText || qText.length < 3) {
                    let container = el.closest('[class*="question"], [class*="item"], [class*="topic"], [class*="stem"], [class*="writing"], [class*="translation"], tr, li, p');
                    if (container) {
                        const clone = container.cloneNode(true);
                        clone.querySelectorAll('input, textarea, select, button').forEach(e => e.remove());
                        qText = clone.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                    }
                }
                // 兜底2：找前面的兄弟元素或父元素
                if (!qText || qText.length < 3) {
                    let prev = el.previousElementSibling || el.parentElement;
                    if (prev) qText = (prev.innerText || '').trim().substring(0, 200);
                }
                // 兜底3：对于 writing/translation 类型，从整个 partDiv 中按题号提取
                if ((!qText || qText.length < 3) && qnum > 0 && scanRoot) {
                    // 找包含 "题目编号" 文本的元素
                    const allTexts = scanRoot.querySelectorAll('p, div, span, td, li');
                    for (const t of allTexts) {
                        const txt = t.innerText.trim();
                        // 匹配 "51." "51、" "(51)" "Q51" 等模式
                        if ((txt.indexOf(qnum + '.') === 0 || txt.indexOf(qnum + ',') === 0) && txt.length > 10) {
                            qText = txt.substring(0, 500);
                            break;
                        }
                    }
                }
                // 兜底4：如果还是没有，用整个 partDiv 的文本按段落提取
                if ((!qText || qText.length < 3) && qnum > 0 && scanRoot) {
                    const paragraphs = scanRoot.innerText.split('\n').filter(l => l.trim().length > 5);
                    for (const p of paragraphs) {
                        if (p.indexOf(qnum + '.') === 0 || p.indexOf(qnum + ',') === 0) {
                            qText = p.trim().substring(0, 500);
                            break;
                        }
                    }
                }
                result.textInputs.push({
                    index: qnum || (1000 + result.textInputs.length),
                    text: qText.substring(0, 400),
                    id: el.id || '', name: el.name || '',
                    tag: el.tagName, visible: true,
                    cls: (el.className || '').substring(0, 60),
                    qtype: qtype, qnum: qnum,
                    type: el.type || 'text'
                });
            });
            // 2b. 扫描 contenteditable 元素
            scanRoot.querySelectorAll('[contenteditable="true"]').forEach((el, idx) => {
                if (el.offsetParent === null) return;
                let qText = '';
                let container = el.closest('[class*="question"], [class*="item"], tr, li, p');
                if (container) {
                    const clone = container.cloneNode(true);
                    clone.querySelectorAll('[contenteditable]').forEach(e => e.removeAttribute('contenteditable'));
                    qText = clone.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                }
                if (qText && qText.length >= 3) {
                    result.textInputs.push({
                        index: 2000 + idx, text: qText.substring(0, 400),
                        id: el.id || '', name: el.name || '',
                        tag: el.tagName, visible: true,
                        cls: (el.className || '').substring(0, 60),
                        qtype: 'editable', qnum: 0, type: 'contenteditable'
                    });
                }
            });
            // 2c. 扫描 iframe
            scanRoot.querySelectorAll('iframe').forEach((iframe, fi) => {
                try {
                    const iDoc = iframe.contentDocument;
                    if (!iDoc) return;
                    iDoc.querySelectorAll('input[type="text"], textarea').forEach((el, idx) => {
                        if (el.offsetParent === null) return;
                        let qText = '';
                        let container = el.closest('[class*="question"], [class*="item"], tr, li, p');
                        if (container) {
                            const clone = container.cloneNode(true);
                            clone.querySelectorAll('input, textarea, select').forEach(e => e.remove());
                            qText = clone.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                        }
                        result.textInputs.push({
                            index: 3000 + idx, text: qText.substring(0, 400),
                            id: el.id || '', name: el.name || '',
                            tag: el.tagName, visible: true,
                            cls: (el.className || '').substring(0, 60),
                            qtype: 'iframe', qnum: 0, type: 'text', iframe: fi
                        });
                    });
                } catch(e) {}
            });
            // 2b. 扫描 iframe
            scanRoot.querySelectorAll('iframe').forEach((iframe, fi) => {
                try {
                    const iDoc = iframe.contentDocument;
                    if (!iDoc) return;
                    iDoc.querySelectorAll('input[type="text"], input:not([type]), textarea').forEach((el, idx) => {
                        if (el.type === 'hidden' || el.type === 'radio' || el.type === 'checkbox') return;
                        let container = el.closest('[class*="question"], [class*="item"], tr, li, p');
                        let qText = '';
                        if (container) {
                            const clone = container.cloneNode(true);
                            clone.querySelectorAll('input, textarea, select').forEach(e => e.remove());
                            qText = clone.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                        }
                        result.textInputs.push({
                            index: idx, text: qText.substring(0, 400),
                            id: el.id || '', name: el.name || '',
                            tag: el.tagName, visible: true, iframe: fi
                        });
                    });
                } catch(e) {}
            });
            // 3. 扫描选择题 — 支持多种 DOM 结构
            // 3a. 原生 radio
            const allRadios = scanRoot.querySelectorAll('input[type="radio"]');
            const radioGroups = {};
            allRadios.forEach(r => {
                const name = r.name || r.id || 'group_' + Math.random();
                if (!radioGroups[name]) radioGroups[name] = {options: [], question: ''};
                let optText = '';
                const label = r.closest('label, .option, .choice, td, li, .radio-item, [class*="option"]');
                if (label) optText = label.innerText.trim().substring(0, 200);
                if (!optText) optText = r.value || '';
                radioGroups[name].options.push({
                    value: r.value || '',
                    text: optText,
                    id: r.id || '',
                    element: 'radio'
                });
            });
            Object.keys(radioGroups).forEach(key => {
                const group = radioGroups[key];
                if (group.options.length < 2) return;
                // 找题目 — 多种方式
                const firstRadio = document.querySelector(`input[name="${key}"]`);
                let qText = '';
                if (firstRadio) {
                    // 方式0: WeTest 特定结构 — .test_hov > div 的文本
                    const testHov = firstRadio.closest('.test_hov');
                    if (testHov) {
                        const firstDiv = testHov.querySelector(':scope > div');
                        if (firstDiv) {
                            // 获取 question span 之前的文本
                            const qSpan = firstDiv.querySelector('span[id^="question_"]');
                            let txt = '';
                            if (qSpan) {
                                // question span 在 choiceList 里，不在 firstDiv 里
                                // 直接取 firstDiv 的文本
                                txt = firstDiv.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                            } else {
                                txt = firstDiv.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                            }
                            // 去掉题号
                            txt = txt.replace(/^\d{1,3}[\.、\)\s]+/, '').trim();
                            if (txt.length > 5) qText = txt;
                        }
                    }
                    // 方式1: 向上找 question 容器
                    if (!qText || qText.length < 5) {
                        const parent = firstRadio.closest(
                            '.question-item, .choice-item, .q-item, [class*="question"], tr, li'
                        );
                        if (parent) {
                            const clone = parent.cloneNode(true);
                            clone.querySelectorAll('input, label, .option, .choice, [type="radio"]').forEach(e => e.remove());
                            qText = clone.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                        }
                    }
                    // 方式2: 从更大范围提取
                    if (!qText || qText.length < 5) {
                        let container = firstRadio.parentElement;
                        for (let i = 0; i < 5 && container; i++) {
                            const clone = container.cloneNode(true);
                            clone.querySelectorAll('input, label, .option, .choice, [type="radio"]').forEach(e => e.remove());
                            const txt = clone.innerText.replace(/[ \t\n\r]+/g, ' ').trim();
                            if (txt.length > 10 && txt.length < 500) { qText = txt; break; }
                            container = container.parentElement;
                        }
                    }
                }
                result.radios.push({name: key, question: qText.substring(0, 400), options: group.options});
            });

            // 3b. 非原生选择题（div/li 模拟的 clickable 选项）
            const clickableOptions = document.querySelectorAll(
                '.option-item, .choice-item, [class*="option"], [role="option"], [role="radio"], li[data-value]'
            );
            if (clickableOptions.length > 0 && result.radios.length === 0) {
                // 按题目分组
                const groups = {};
                clickableOptions.forEach(el => {
                    const parent = el.closest('.question-item, .q-item, [class*="question"], [class*="choice"]');
                    const groupId = parent ? (parent.id || parent.className || 'q_' + Math.random()) : 'global';
                    if (!groups[groupId]) groups[groupId] = {question: '', options: []};
                    const optText = el.innerText.trim().substring(0, 200);
                    if (optText) groups[groupId].options.push({text: optText, element: 'div', el: el});
                });
                Object.keys(groups).forEach(key => {
                    const group = groups[key];
                    if (group.options.length >= 2) {
                        const parent = clickableOptions[0].closest('.question-item, .q-item, [class*="question"]');
                        let qText = '';
                        if (parent) {
                            const clone = parent.cloneNode(true);
                            clone.querySelectorAll('[class*="option"], [role="option"], li').forEach(e => e.remove());
                            qText = clone.innerText.replace(/\\s+/g, ' ').trim();
                        }
                        result.allQuestions.push({
                            type: 'clickable_choice',
                            question: qText.substring(0, 400),
                            options: group.options.map(o => ({text: o.text, element: o.element})),
                            groupKey: key
                        });
                    }
                });
            }

            // 4. 下拉选择题
            const selects = scanRoot.querySelectorAll('select');
            selects.forEach((sel, idx) => {
                const opts = [];
                sel.querySelectorAll('option').forEach(opt => {
                    if (opt.value && opt.value !== '') {
                        opts.push({value: opt.value, text: opt.innerText.trim()});
                    }
                });
                if (opts.length >= 2) {
                    let qText = '';
                    const parent = sel.closest('.question-item, .form-group, tr, [class*="question"]');
                    if (parent) {
                        const clone = parent.cloneNode(true);
                        clone.querySelectorAll('select, button').forEach(e => e.remove());
                        qText = clone.innerText.replace(/\\s+/g, ' ').trim();
                    }
                    result.selectBoxes.push({index: idx, question: qText.substring(0, 400), options: opts, id: sel.id});
                }
            });

            return result;
        }