"""
WeLearn 统一启动器（自然柔和风格）
====================================
左侧竖直导航 + 右侧内容区
"""
import os
import sys
import json
import time
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(SCRIPT_DIR, ".launcher_config.json")
sys.path.insert(0, SCRIPT_DIR)
from core.welearn_api import WeLearnClient


def get_python_exe():
    """获取 python.exe 路径（而非 pythonw.exe）"""
    if sys.executable.lower().endswith("pythonw.exe"):
        return sys.executable.replace("pythonw.exe", "python.exe")
    return sys.executable

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except: pass
    return {}

def save_config(cfg):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except: pass

# ── 色系 ──
BG = "#f5f5ec"
SIDEBAR_BG = "#4a5548"
SIDEBAR_FG = "#e8e8d8"
SIDEBAR_ACTIVE = "#D8E887"
SIDEBAR_HOVER = "#5a6558"
ACCENT = "#D8E887"
ACCENT_DARK = "#b8c867"
CARD_BG = "#ffffff"
TEXT = "#3a3a3a"
TEXT2 = "#8a8a7a"
BORDER = "#d5d5c8"
BTN_GREEN = "#7a9e4a"
BTN_OLIVE = "#C9C986"
BTN_STOP = "#c47a7a"


class UnifiedLauncher:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("WeLearn 一体化工具")
        self.root.geometry("900x680")
        self.root.resizable(False, False)
        self.root.configure(bg=BG)
        self.cfg = load_config()
        self.client = None
        self.courses = []
        self.units = []
        self.running = False
        self._build_ui()
        self._show_page("chapter")
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.mainloop()

    # ─── UI ───
    def _build_ui(self):
        self.sidebar = tk.Frame(self.root, bg=SIDEBAR_BG, width=180)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        tk.Label(self.sidebar, text="🎓 WeLearn", bg=SIDEBAR_BG, fg=ACCENT,
                 font=("微软雅黑", 15, "bold")).pack(pady=(22, 18))

        self.nav_buttons = {}
        for key, label in [("chapter", "📘  Chapter Test"), ("wetest", "📗  WeTest"),
                           ("progress", "📙  刷课程进度"), ("time", "⏱️  刷时长")]:
            btn = tk.Button(self.sidebar, text=label, bg=SIDEBAR_BG, fg=SIDEBAR_FG,
                            activebackground=SIDEBAR_ACTIVE, activeforeground=TEXT,
                            font=("微软雅黑", 11), relief="flat", anchor="w", padx=18, pady=10,
                            cursor="hand2", command=lambda k=key: self._show_page(k))
            btn.pack(fill="x", padx=8, pady=2)
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg=SIDEBAR_HOVER) if b["bg"] != SIDEBAR_ACTIVE else None)
            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=SIDEBAR_BG) if b["bg"] != SIDEBAR_ACTIVE else None)
            self.nav_buttons[key] = btn

        tk.Frame(self.sidebar, bg="#5a6558", height=1).pack(fill="x", padx=20, pady=12)
        self.acc_label = tk.Label(self.sidebar, text="未登录", bg=SIDEBAR_BG, fg="#a0a090",
                                  font=("微软雅黑", 9), wraplength=155, justify="left")
        self.acc_label.pack(side="bottom", padx=12, pady=12, anchor="w")

        self.content = tk.Frame(self.root, bg=BG)
        self.content.pack(side="right", fill="both", expand=True)
        self._build_top_bar()
        self.pages = {}
        self.pages["chapter"] = self._build_chapter_page()
        self.pages["wetest"] = self._build_wetest_page()
        self.pages["progress"] = self._build_progress_page()
        self.pages["time"] = self._build_time_page()
        self._build_log()

    def _build_top_bar(self):
        bar = tk.Frame(self.content, bg=CARD_BG)
        bar.pack(fill="x", padx=15, pady=(15, 0))

        r1 = tk.Frame(bar, bg=CARD_BG)
        r1.pack(fill="x", padx=15, pady=(10, 2))
        tk.Label(r1, text="API Key:", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(side="left")
        self.api_key_var = tk.StringVar(value=self.cfg.get("api_key", ""))
        self.api_entry = tk.Entry(r1, textvariable=self.api_key_var, show="•", width=28,
                                  font=("Consolas", 9), relief="flat", bg="#f8f8f0",
                                  highlightbackground=BORDER, highlightthickness=1)
        self.api_entry.pack(side="left", padx=(5, 2))
        self.show_var = tk.BooleanVar()
        tk.Checkbutton(r1, text="显示", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 8),
                       selectcolor="#f0f0e8", variable=self.show_var,
                       command=lambda: self.api_entry.config(show="" if self.show_var.get() else "•")).pack(side="left")
        tk.Label(r1, text="  用户:", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(side="left")
        self.user_var = tk.StringVar(value=self.cfg.get("username", ""))
        tk.Entry(r1, textvariable=self.user_var, width=12, font=("Consolas", 9),
                 relief="flat", bg="#f8f8f0", highlightbackground=BORDER, highlightthickness=1).pack(side="left", padx=3)
        tk.Label(r1, text="密码:", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(side="left")
        self.pass_var = tk.StringVar(value=self.cfg.get("password", ""))
        tk.Entry(r1, textvariable=self.pass_var, show="•", width=10, font=("Consolas", 9),
                 relief="flat", bg="#f8f8f0", highlightbackground=BORDER, highlightthickness=1).pack(side="left", padx=3)
        self.login_btn = tk.Button(r1, text="🔍 登录", bg=ACCENT, fg=TEXT,
                                   font=("微软雅黑", 9, "bold"), activebackground=ACCENT_DARK,
                                   relief="flat", padx=10, pady=2, cursor="hand2", command=self._do_login)
        self.login_btn.pack(side="left", padx=8)

        r2 = tk.Frame(bar, bg=CARD_BG)
        r2.pack(fill="x", padx=15, pady=(2, 10))
        tk.Label(r2, text="课程:", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(side="left")
        self.course_var = tk.StringVar()
        self.course_combo = ttk.Combobox(r2, textvariable=self.course_var, width=45, state="readonly")
        self.course_combo.pack(side="left", padx=5)
        self.course_combo.set("请先登录获取课程")
        self.course_combo.bind("<<ComboboxSelected>>", self._on_course_select)
        self.cid_label = tk.Label(r2, text="", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9))
        self.cid_label.pack(side="left", padx=5)

    def _card(self, parent, title):
        f = tk.Frame(parent, bg=CARD_BG, highlightbackground=BORDER, highlightthickness=1)
        tk.Label(f, text=title, bg=CARD_BG, fg=TEXT, font=("微软雅黑", 11, "bold")).pack(anchor="w", padx=18, pady=(14, 5))
        return f

    def _build_chapter_page(self):
        p = tk.Frame(self.content, bg=BG)
        c = self._card(p, "📘 Chapter Test — AI 自动答题")
        c.pack(fill="x", padx=15, pady=10)
        tk.Label(c, text="使用 DeepSeek AI 自动完成 Chapter Test，浏览器模式",
                 bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(anchor="w", padx=18, pady=3)
        f = tk.Frame(c, bg=CARD_BG)
        f.pack(fill="x", padx=18, pady=12)
        self.auto_submit_ch = tk.BooleanVar(value=self.cfg.get("auto_submit", True))
        tk.Checkbutton(f, text="自动交卷", bg=CARD_BG, fg=TEXT, font=("微软雅黑", 10),
                       selectcolor="#f0f0e8", variable=self.auto_submit_ch).pack(side="left")
        tk.Button(f, text="📘 启动 Chapter Test", bg=BTN_GREEN, fg="white",
                  font=("微软雅黑", 11, "bold"), activebackground="#6a8e3a", relief="flat",
                  padx=20, pady=8, cursor="hand2",
                  command=lambda: self._launch_browser("chapter")).pack(side="right", padx=10)
        return p

    def _build_wetest_page(self):
        p = tk.Frame(self.content, bg=BG)
        c = self._card(p, "📗 WeTest — AI 自动答题")
        c.pack(fill="x", padx=15, pady=10)
        tk.Label(c, text="使用 DeepSeek AI 自动完成 WeTest，浏览器模式",
                 bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(anchor="w", padx=18, pady=3)
        f1 = tk.Frame(c, bg=CARD_BG)
        f1.pack(fill="x", padx=18, pady=5)
        tk.Label(f1, text="测试 URL:", bg=CARD_BG, fg=TEXT, font=("微软雅黑", 10)).pack(side="left")
        self.wetest_url_var = tk.StringVar(value=self.cfg.get("wetest_url", ""))
        tk.Entry(f1, textvariable=self.wetest_url_var, width=50, font=("Consolas", 9),
                 relief="flat", bg="#f8f8f0", highlightbackground=BORDER, highlightthickness=1).pack(side="left", padx=8)
        f2 = tk.Frame(c, bg=CARD_BG)
        f2.pack(fill="x", padx=18, pady=12)
        tk.Button(f2, text="📗 启动 WeTest", bg=BTN_GREEN, fg="white",
                  font=("微软雅黑", 11, "bold"), activebackground="#6a8e3a", relief="flat",
                  padx=20, pady=8, cursor="hand2",
                  command=lambda: self._launch_browser("wetest")).pack(side="right", padx=10)
        return p

    def _build_progress_page(self):
        p = tk.Frame(self.content, bg=BG)
        c = self._card(p, "📙 刷课程进度 — API 直接提交（无需浏览器）")
        c.pack(fill="x", padx=15, pady=10)
        f1 = tk.Frame(c, bg=CARD_BG)
        f1.pack(fill="x", padx=18, pady=5)
        tk.Label(f1, text="单元:", bg=CARD_BG, fg=TEXT, font=("微软雅黑", 10)).pack(side="left")
        self.unit_var = tk.StringVar()
        self.unit_combo = ttk.Combobox(f1, textvariable=self.unit_var, width=40, state="readonly")
        self.unit_combo.pack(side="left", padx=8)
        self.unit_combo.set("请先选择课程")
        tk.Button(f1, text="刷新", bg="#e8e8d8", fg=TEXT, font=("微软雅黑", 9),
                  activebackground="#d8d8c8", relief="flat", padx=8, cursor="hand2",
                  command=self._load_units).pack(side="left", padx=5)
        f2 = tk.Frame(c, bg=CARD_BG)
        f2.pack(fill="x", padx=18, pady=5)
        tk.Label(f2, text="正确率:", bg=CARD_BG, fg=TEXT, font=("微软雅黑", 10)).pack(side="left")
        self.accuracy_var = tk.StringVar(value="85")
        tk.Entry(f2, textvariable=self.accuracy_var, width=5, font=("Consolas", 10),
                 relief="flat", bg="#f8f8f0", highlightbackground=BORDER, highlightthickness=1).pack(side="left", padx=5)
        tk.Label(f2, text="%（70-100）", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(side="left")
        self.skip_done_var = tk.BooleanVar(value=True)
        tk.Checkbutton(f2, text="跳过已完成", bg=CARD_BG, fg=TEXT, font=("微软雅黑", 10),
                       selectcolor="#f0f0e8", variable=self.skip_done_var).pack(side="left", padx=20)
        f3 = tk.Frame(c, bg=CARD_BG)
        f3.pack(fill="x", padx=18, pady=12)
        tk.Button(f3, text="📙 开始刷进度", bg=BTN_OLIVE, fg="white",
                  font=("微软雅黑", 11, "bold"), activebackground="#b9b976", relief="flat",
                  padx=20, pady=8, cursor="hand2", command=self._start_progress).pack(side="left")
        tk.Button(f3, text="⏹ 停止", bg=BTN_STOP, fg="white", font=("微软雅黑", 10),
                  activebackground="#b46a6a", relief="flat", padx=12, pady=6,
                  cursor="hand2", command=self._stop).pack(side="left", padx=10)
        self.prog_bar = ttk.Progressbar(c, mode="determinate")
        self.prog_bar.pack(fill="x", padx=18, pady=(0, 5))
        self.prog_label = tk.Label(c, text="", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9))
        self.prog_label.pack(anchor="w", padx=18, pady=(0, 14))
        return p

    def _build_time_page(self):
        p = tk.Frame(self.content, bg=BG)
        c = self._card(p, "⏱️ 刷时长 — 模拟学习心跳（无需浏览器）")
        c.pack(fill="x", padx=15, pady=10)
        f1 = tk.Frame(c, bg=CARD_BG)
        f1.pack(fill="x", padx=18, pady=5)
        tk.Label(f1, text="单元:", bg=CARD_BG, fg=TEXT, font=("微软雅黑", 10)).pack(side="left")
        self.time_unit_var = tk.StringVar()
        self.time_unit_combo = ttk.Combobox(f1, textvariable=self.time_unit_var, width=40, state="readonly")
        self.time_unit_combo.pack(side="left", padx=8)
        self.time_unit_combo.set("请先选择课程")
        f2 = tk.Frame(c, bg=CARD_BG)
        f2.pack(fill="x", padx=18, pady=5)
        tk.Label(f2, text="时长:", bg=CARD_BG, fg=TEXT, font=("微软雅黑", 10)).pack(side="left")
        self.duration_var = tk.StringVar(value="5")
        tk.Entry(f2, textvariable=self.duration_var, width=5, font=("Consolas", 10),
                 relief="flat", bg="#f8f8f0", highlightbackground=BORDER, highlightthickness=1).pack(side="left", padx=5)
        tk.Label(f2, text="分钟", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(side="left")
        tk.Label(f2, text="  倍速:", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(side="left")
        self.speed_var = tk.StringVar(value="10")
        tk.OptionMenu(f2, self.speed_var, "1", "5", "10", "20", "60", "90", "120", "200").pack(side="left", padx=3)
        tk.Label(f2, text="自定义:", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9)).pack(side="left")
        self.custom_speed_var = tk.StringVar(value="")
        self.custom_speed_entry = tk.Entry(f2, textvariable=self.custom_speed_var, width=5, font=("Consolas", 10),
                                           relief="flat", bg="#f8f8f0", highlightbackground=BORDER, highlightthickness=1)
        self.custom_speed_entry.pack(side="left", padx=3)
        f3 = tk.Frame(c, bg=CARD_BG)
        f3.pack(fill="x", padx=18, pady=12)
        tk.Button(f3, text="⏱️ 开始刷时长", bg="#8a9a6a", fg="white",
                  font=("微软雅黑", 11, "bold"), activebackground="#7a8a5a", relief="flat",
                  padx=20, pady=8, cursor="hand2", command=self._start_time).pack(side="left")
        tk.Button(f3, text="⏹ 停止", bg=BTN_STOP, fg="white", font=("微软雅黑", 10),
                  activebackground="#b46a6a", relief="flat", padx=12, pady=6,
                  cursor="hand2", command=self._stop).pack(side="left", padx=10)
        self.time_bar = ttk.Progressbar(c, mode="determinate")
        self.time_bar.pack(fill="x", padx=18, pady=(0, 5))
        self.time_label = tk.Label(c, text="", bg=CARD_BG, fg=TEXT2, font=("微软雅黑", 9))
        self.time_label.pack(anchor="w", padx=18, pady=(0, 14))
        return p

    def _build_log(self):
        f = tk.Frame(self.content, bg=CARD_BG, highlightbackground=BORDER, highlightthickness=1)
        f.pack(fill="both", expand=True, padx=15, pady=(5, 15))
        tk.Label(f, text="📋 运行日志", bg=CARD_BG, fg=TEXT, font=("微软雅黑", 10, "bold")).pack(anchor="w", padx=12, pady=(8, 2))
        self.log_text = scrolledtext.ScrolledText(f, height=5, font=("Consolas", 9), state="disabled",
                                                   bg="#1e1e1e", fg="#d4d4d4", insertbackground="white", bd=0)
        self.log_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    # ─── 页面切换 ───
    def _show_page(self, key):
        for p in self.pages.values():
            p.pack_forget()
        self.pages[key].pack(fill="both", expand=True)
        for k, b in self.nav_buttons.items():
            b.config(bg=SIDEBAR_ACTIVE if k == key else SIDEBAR_BG,
                     fg=TEXT if k == key else SIDEBAR_FG)

    def _log(self, msg):
        def _do():
            self.log_text.config(state="normal")
            self.log_text.insert("end", f"[{time.strftime('%H:%M:%S')}] {msg}\n")
            self.log_text.see("end")
            self.log_text.config(state="disabled")
        self.root.after(0, _do)

    # ─── 登录 & 课程 ───
    def _do_login(self):
        u, p = self.user_var.get().strip(), self.pass_var.get().strip()
        if not u or not p:
            messagebox.showwarning("缺少信息", "请填写用户名和密码！"); return
        self.login_btn.config(state="disabled", text="登录中...")
        self._log("SSO 登录中...")
        def _w():
            c = WeLearnClient()
            ok, msg = c.login(u, p)
            if not ok:
                self.root.after(0, lambda: self._login_done(False, msg, None, [])); return
            self._log("登录成功，获取课程列表...")
            ok2, cl, msg2 = c.get_courses()
            self.root.after(0, lambda: self._login_done(ok2, msg2, c, cl))
        threading.Thread(target=_w, daemon=True).start()

    def _login_done(self, ok, msg, client, courses):
        self.login_btn.config(state="normal", text="🔍 登录")
        if ok:
            self.client, self.courses = client, courses
            self.acc_label.config(text=f"✅ {self.user_var.get()}\n{msg}", fg="#a0c060")
            self.course_combo["values"] = [c.get("coursename", c.get("name", "?")) for c in courses]
            if courses:
                self.course_combo.current(0); self._on_course_select(None)
            self._log(f"✅ {msg}")
        else:
            self.acc_label.config(text=f"❌ {msg}", fg="#d08080")
            self._log(f"❌ {msg}")

    def _on_course_select(self, _):
        i = self.course_combo.current()
        if 0 <= i < len(self.courses):
            self.cid_label.config(text=f"CID: {self.courses[i].get('cid', '?')}")
            self._load_units()

    def _get_cid(self):
        i = self.course_combo.current()
        return str(self.courses[i].get("cid", "")) if 0 <= i < len(self.courses) else ""

    def _load_units(self):
        if not self.client: return
        cid = self._get_cid()
        if not cid: return
        self._log(f"获取课程 {cid} 的单元列表...")
        ok, info, msg = self.client.get_course_info(cid)
        if ok:
            self.units = info["units"]
            d = [f"Unit {u.get('unitidx', i+1)}: {u.get('name', u.get('title', '?'))}" for i, u in enumerate(self.units)]
            self.unit_combo["values"] = d; self.time_unit_combo["values"] = d
            if d: self.unit_combo.current(0); self.time_unit_combo.current(0)
            self._log(f"✅ {msg}，共 {len(self.units)} 个单元")
        else:
            self._log(f"❌ {msg}")

    # ─── 浏览器模式 ───
    def _launch_browser(self, mode):
        api_key = self.api_key_var.get().strip()
        u, p = self.user_var.get().strip(), self.pass_var.get().strip()
        if not api_key: messagebox.showwarning("缺少信息", "请填写 DeepSeek API Key！"); return
        if not u or not p: messagebox.showwarning("缺少信息", "请填写用户名和密码！"); return
        self._save_config()
        env = os.environ.copy()
        env["DEEPSEEK_API_KEY"] = api_key
        env["WELEARN_USERNAME"] = u; env["WELEARN_PASSWORD"] = p
        env["WELEARN_AUTO_SUBMIT"] = "1" if self.auto_submit_ch.get() else "0"
        if mode == "chapter":
            cid = self._get_cid()
            if not cid: messagebox.showwarning("缺少信息", "请先获取课程并选择！"); return
            env["WELEARN_CID"] = cid
            script = os.path.join(SCRIPT_DIR, "chapter_v11.py")
            args = [get_python_exe(), script]
            self._log(f"启动 Chapter Test: {self.course_combo.get()}")
        else:
            url = self.wetest_url_var.get().strip()
            if not url: messagebox.showwarning("缺少信息", "请填写 WeTest URL！"); return
            cid = self._get_cid()
            if cid: env["WELEARN_CID"] = cid
            script = os.path.join(SCRIPT_DIR, "wetest_auto.py")
            args = [get_python_exe(), script, url]
            self._log("启动 WeTest...")
        self._log("新窗口将弹出，请在新窗口中操作")
        def _r():
            try:
                proc = subprocess.Popen(args, env=env, cwd=SCRIPT_DIR, creationflags=subprocess.CREATE_NEW_CONSOLE)
                self._log(f"进程已启动 (PID={proc.pid})")
                proc.wait()
                self._log(f"{'✅ 完成' if proc.returncode == 0 else f'⚠️ 退出码: {proc.returncode}'}")
            except Exception as e:
                self._log(f"❌ 启动失败: {e}")
        threading.Thread(target=_r, daemon=True).start()

    # ─── 刷进度 ───
    def _start_progress(self):
        if not self.client: messagebox.showwarning("未登录", "请先登录！"); return
        cid = self._get_cid()
        if not cid: messagebox.showwarning("未选课", "请先选择课程！"); return
        ui = self.unit_combo.current()
        if ui < 0: messagebox.showwarning("未选单元", "请先选择单元！"); return
        try:
            acc = int(self.accuracy_var.get().strip())
            if not (70 <= acc <= 100): raise ValueError
        except: messagebox.showwarning("参数错误", "正确率必须是 70-100！"); return
        self.running = True
        self._log(f"开始刷进度：CID={cid}, Unit={ui+1}, 正确率={acc}%")
        def _w():
            ok, info, msg = self.client.get_course_info(cid)
            if not ok: self._log(f"❌ {msg}"); return
            uid, classid = info["uid"], info["classid"]
            ok2, leaves, msg2 = self.client.get_sco_leaves(cid, uid, classid, ui)
            if not ok2: self._log(f"❌ {msg2}"); return
            total, done, skip, fail = len(leaves), 0, 0, 0
            for i, crs in enumerate(leaves):
                if not self.running: self._log("⏹ 已停止"); break
                scoid = crs.get("id", ""); title = crs.get("location", f"课时{scoid}")
                if crs.get("isvisible") == "false": skip += 1; continue
                if self.skip_done_var.get() and "未" not in crs.get("iscomplete", ""): skip += 1; continue
                self._log(f"[{i+1}/{total}] {title}")
                ok3, m = self.client.submit_progress(cid, uid, classid, scoid, str(acc))
                if ok3: done += 1; self._log(f"  ✅ {m}")
                else: fail += 1; self._log(f"  ❌ {m}")
                pct = (i+1)/total*100
                self.root.after(0, lambda p=pct: self.prog_bar.config(value=p))
                self.root.after(0, lambda d=done, s=skip, f=fail, t=total:
                               self.prog_label.config(text=f"✅ {d}  ⏭ {s}  ❌ {f}  / {t}"))
                time.sleep(0.3)
            self._log(f"✅ 刷进度完成：成功 {done}，跳过 {skip}，失败 {fail}")
            self.running = False
        threading.Thread(target=_w, daemon=True).start()

    # ─── 刷时长 ───
    def _start_time(self):
        if not self.client: messagebox.showwarning("未登录", "请先登录！"); return
        cid = self._get_cid()
        if not cid: messagebox.showwarning("未选课", "请先选择课程！"); return
        ui = self.time_unit_combo.current()
        if ui < 0: messagebox.showwarning("未选单元", "请先选择单元！"); return
        try:
            mins = int(self.duration_var.get().strip())
            if mins <= 0: raise ValueError
        except: messagebox.showwarning("参数错误", "时长必须是正整数！"); return
        self.running = True
        self._stop_event = threading.Event()
        custom = self.custom_speed_var.get().strip()
        if custom:
            try:
                speed = int(custom)
                if speed <= 0: raise ValueError
            except: messagebox.showwarning("参数错误", "自定义倍速必须是正整数！"); return
        else:
            speed = int(self.speed_var.get())
        real_secs = max(mins * 60 // speed, 1)
        self._log(f"开始刷时长：{mins} 分钟（{speed}x 倍速，实际 {real_secs} 秒）")
        def _w():
            ok, info, msg = self.client.get_course_info(cid)
            if not ok: self._log(f"❌ {msg}"); return
            uid, classid = info["uid"], info["classid"]
            ok2, leaves, msg2 = self.client.get_sco_leaves(cid, uid, classid, ui)
            if not ok2: self._log(f"❌ {msg2}"); return
            tgt = next((c for c in leaves if "未" in c.get("iscomplete","") and c.get("isvisible")!="false"), leaves[0] if leaves else None)
            if not tgt: self._log("❌ 没有可用课时"); return
            scoid = tgt.get("id", ""); self._log(f"目标: {tgt.get('location', scoid)}")
            def _cb(t, total):
                self.root.after(0, lambda p=t/total*100: self.time_bar.config(value=p))
                self.root.after(0, lambda t=t, tt=total: self.time_label.config(text=f"{t//60}分{t%60}秒 / {tt//60}分钟"))
            ok3, m = self.client.simulate_time(cid, uid, scoid, mins * 60, _cb, self._stop_event, speed)
            self._log(f"{'✅' if ok3 else '❌'} {m}")
            self.running = False
        threading.Thread(target=_w, daemon=True).start()

    def _stop(self):
        self.running = False
        if hasattr(self, '_stop_event') and self._stop_event:
            self._stop_event.set()
        self._log("正在停止...")

    def _save_config(self):
        save_config({"api_key": self.api_key_var.get().strip(), "username": self.user_var.get().strip(),
                      "password": self.pass_var.get().strip(), "wetest_url": self.wetest_url_var.get().strip(),
                      "auto_submit": self.auto_submit_ch.get()})

    def _on_close(self):
        self.running = False; self._save_config(); self.root.destroy()

if __name__ == "__main__":
    UnifiedLauncher()
