Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
WshShell.CurrentDirectory = fso.GetParentFolderName(WScript.ScriptFullName)
Dim selfPath
selfPath = WScript.ScriptFullName

Dim pyCheck
pyCheck = WshShell.Run("cmd /c python --version", 0, True)

If pyCheck <> 0 Then
    Dim answer
    answer = MsgBox("Python not found. Auto install?" & vbCrLf & vbCrLf & _
                    "Yes = Auto install Python 3.12" & vbCrLf & _
                    "No = Exit (manual install needed)", vbYesNo + vbQuestion, "WeLearn")
    If answer = vbNo Then
        MsgBox "Cannot run without Python." & vbCrLf & "https://www.python.org/downloads/", vbExclamation, "WeLearn"
        WScript.Quit
    End If

    MsgBox "Downloading Python 3.12, please wait...", vbInformation, "WeLearn"

    WshShell.Run "powershell -Command ""$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile 'python_installer.exe'""", 0, True

    If Not fso.FileExists(WshShell.CurrentDirectory & "\python_installer.exe") Then
        MsgBox "Download failed! Install manually: https://www.python.org/downloads/", vbCritical, "WeLearn"
        WScript.Quit
    End If

    WshShell.Run """python_installer.exe"" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0", 0, True

    On Error Resume Next
    fso.DeleteFile WshShell.CurrentDirectory & "\python_installer.exe", True
    On Error GoTo 0

    pyCheck = WshShell.Run("cmd /c python --version", 0, True)
    If pyCheck <> 0 Then
        MsgBox "Python installed but needs restart. Please reboot and try again.", vbExclamation, "WeLearn"
        WScript.Quit
    End If

    MsgBox "Python installed!", vbInformation, "WeLearn"
End If

Dim depCheck
depCheck = WshShell.Run("cmd /c python -c ""import playwright, requests""", 0, True)

If depCheck <> 0 Then
    WshShell.Run "cmd /c pip install -r requirements.txt && python -m playwright install chromium && wscript """"" & selfPath & """""", 0, False
    MsgBox "Installing dependencies, please wait...", vbInformation, "WeLearn"
Else
    WshShell.Run "pythonw unified_launcher.py", 0, False
End If
