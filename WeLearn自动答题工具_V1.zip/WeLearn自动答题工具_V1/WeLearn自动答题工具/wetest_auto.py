"""
WeTest 自动答题工具（Playwright 版）
读取粘贴的链接，用 Playwright 直接打开页面做题
"""
import sys
import os
import time
import json
import re
from concurrent.futures import ThreadPoolExecutor

# Windows 控制台 UTF-8 支持
try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except: pass

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

# ========== 配置 ==========
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(SCRIPT_DIR, ".launcher_config.json")

API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
if not API_KEY:
    try:
        import json as _json
        with open(CONFIG_FILE, encoding="utf-8") as _f:
            API_KEY = _json.load(_f).get("api_key", "")
    except Exception:
        pass

# ========== 日志 ==========
def log(msg):
    t = time.strftime("%H:%M:%S")
    line = f"[{t}] {msg}"
    print(line, flush=True)

# ========== AI 调用 ==========
def call_ai(prompt, system="", temperature=0.1, max_tokens=1500):
    import requests as req
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    body = {
        "model": "deepseek-chat",
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
        "temperature": temperature, "max_tokens": max_tokens
    }
    try:
        r = req.post("https://api.deepseek.com/v1/chat/completions", headers=headers, json=body, timeout=60)
        data = r.json()
        if "choices" not in data:
            log(f"  AI返回错误: {data}")
            return ""
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        log(f"  AI调用失败: {e}")
        return ""

# ========== 答案提取 ==========
def extract_choice_letter(text, num_options=4):
    if not text: return None
    text = text.strip()
    max_letter = chr(ord('A') + min(num_options - 1, 25))
    pure = re.findall(rf'\b([{max_letter}])\b', text.upper())
    if pure: return ''.join(sorted(set(pure)))
    m = re.search(rf'(?:答案|选|选择|answer)[是为：:\s]*([{max_letter}])', text, re.IGNORECASE)
    if m: return m.group(1).upper()
    for ch in text.upper():
        if 'A' <= ch <= max_letter: return ch
    return None

def extract_fill_answer(text):
    if not text: return ""
    text = text.strip()
    text = re.sub(r'```[\s\S]*?```', '', text)
    text = re.sub(r'`([^`]*)`', r'\1', text)
    text = re.sub(r'\*{1,2}([^*]*)\*{1,2}', r'\1', text)
    text = text.strip('"\'""' + "''")
    text = re.sub(r'^(?:答案[是为：:]?\s*|answer[：:\s]?|the answer is\s*)', '', text, flags=re.IGNORECASE).strip()
    text = re.sub(r'^\d{1,3}[\.、\)\s]+', '', text).strip()
    text = text.rstrip('.').strip()
    text = re.sub(r'\s*[（(][^）)]*[）)]$', '', text).strip()
    if '\n' in text:
        first_line = text.split('\n')[0].strip()
        if first_line and len(first_line) < 200: text = first_line
    return text.strip()

# ========== SSO 登录 ==========
import requests as _req
from core.crypto import generate_cipher_text
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter

class TLSAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        import ssl
        ctx = ssl.create_default_context()
        ctx.set_ciphers("DEFAULT@SECLEVEL=1")
        kwargs["ssl_context"] = ctx
        super().init_poolmanager(*args, **kwargs)

def sso_login(u, p):
    sess = _req.Session()
    sess.mount('https://', TLSAdapter(max_retries=3))
    sess.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
    r = sess.get("https://welearn.sflep.com/user/prelogin.aspx?loginret=http://welearn.sflep.com/user/loginredirect.aspx", timeout=60)
    if r.status_code != 200: return None, f"预登录失败: {r.status_code}"
    parts = r.url.split("%26")
    if len(parts) < 7: return None, "URL 解析失败"
    cc = parts[4].split("%3D")[1]; st = parts[6].split("%3D")[1]
    rturl = (f"/connect/authorize/callback?client_id=welearn_web&redirect_uri=https%3A%2F%2Fwelearn.sflep.com%2Fsignin-sflep"
             f"&response_type=code&scope=openid%20profile%20email%20phone%20address"
             f"&code_challenge={cc}&code_challenge_method=S256&state={st}"
             f"&x-client-SKU=ID_NET472&x-client-ver=6.32.1.0")
    enpwd = generate_cipher_text(p)
    r = sess.post("https://sso.sflep.com/idsvr/account/login",
        data={"rturl": rturl, "account": u, "pwd": enpwd[0], "ts": enpwd[1]}, timeout=60)
    if r.status_code != 200: return None, f"登录请求失败: {r.status_code}"
    j = r.json()
    if j.get("code") == 1: return None, "账号或密码错误"
    if j.get("code") != 0: return None, f"登录失败({j.get('code')})"
    try: sess.get("https://welearn.sflep.com/user/prelogin.aspx?loginret=http://welearn.sflep.com/user/loginredirect.aspx", timeout=60)
    except: pass
    return sess, "OK"

# ========== 主流程 ==========
def main():
    # 获取 URL
    if len(sys.argv) > 1:
        url = sys.argv[1]
    else:
        print("=" * 50)
        print("WeTest 自动答题工具")
        print("=" * 50)
        print("\n请把浏览器中的 Wetest 测试地址粘贴到这里：")
        url = input(">>> ").strip()

    if not url or "wetest" not in url:
        print("❌ 无效的 Wetest URL")
        return

    if not API_KEY:
        print("❌ 未设置 DEEPSEEK_API_KEY")
        return

    log(f"URL: {url[:80]}")

    # SSO 登录
    log("\n[1] SSO 登录...")
    username = os.environ.get("WELEARN_USERNAME", "")
    password = os.environ.get("WELEARN_PASSWORD", "")
    if not username or not password:
        log("❌ 未设置用户名或密码，请在启动器中填写")
        input("按回车退出...")
        return
    session, msg = sso_login(username, password)
    if not session:
        log(f"❌ {msg}")
        input("按回车退出...")
        return
    log(f"  ✅ 登录成功, {len(list(session.cookies))} cookies")

    # 从 URL 提取 testKey 和 wlToken
    from urllib.parse import urlparse, parse_qs
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    test_key = params.get('testKey', [''])[0]
    cid = os.environ.get("WELEARN_CID", "")

    # 找到 taskid 和跳转 URL
    import re as _re
    taskid = ""
    redirect_url = ""
    if cid:
        log("  获取测试列表...")
        # 先从 course_info 页面找 taskid（兼容旧版）
        r = session.get(f"https://welearn.sflep.com/student/course_info.aspx?cid={cid}", timeout=30)
        task_ids = _re.findall(r'StartTaskClassTest\((\d+)\)', r.text)

        # 如果 course_info 没找到，用任务列表 API
        if not task_ids:
            uid_match = _re.search(r'"uid":\s*(\d+),', r.text)
            classid_match = _re.search(r'"classid":"(\w+)"', r.text)
            if uid_match and classid_match:
                uid, classid = uid_match.group(1), classid_match.group(1)
                r_task = session.get(
                    "https://welearn.sflep.com/ajax/task.aspx",
                    params={"action": "gettasklist", "cid": cid, "classid": classid, "uid": uid, "s": "100", "pi": "1"},
                    headers={"Referer": f"https://welearn.sflep.com/student/course_info.aspx?cid={cid}"},
                    timeout=15,
                )
                if r_task.status_code == 200:
                    data = r_task.json()
                    if data.get("ret") == 0:
                        for t in data.get("list", []):
                            m = t.get("TaskMethod", "")
                            found = _re.findall(r'StartTaskClassTest\((\d+)\)', m)
                            task_ids.extend(found)
                        log(f"  任务列表找到 {len(task_ids)} 个测试")

        # 尝试每个 taskid 获取新的 wlToken
        for tid in task_ids:
            r2 = session.get(f"https://welearn.sflep.com/test/test.aspx?taskid={tid}&cid={cid}", timeout=30, allow_redirects=True)
            if 'wlToken' in r2.url:
                p = parse_qs(urlparse(r2.url).query)
                tk = p.get('testKey', [''])[0]
                if tk == test_key or not test_key:
                    taskid = tid
                    redirect_url = r2.url
                    log(f"  ✅ 获取到新 wlToken (taskid={tid})")
                    break

    # 如果找不到新 token，检查旧 URL 是否还能用
    if not redirect_url:
        log("  ⚠️ 无法获取新 wlToken，尝试使用缓存 URL...")

    log("\n[2] 启动浏览器...")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        # 注入 welearn cookies
        context.add_cookies([{"name": c.name, "value": c.value, "domain": c.domain.lstrip("."),
                              "path": c.path or "/", "httpOnly": False, "secure": False} for c in session.cookies])
        page = context.new_page()

        # 访问测试页
        if redirect_url:
            log(f"  打开测试页 (新 wlToken)...")
            page.goto(redirect_url, timeout=60000)
        elif taskid and cid:
            log(f"  打开测试页 (taskid={taskid})...")
            page.goto(f"https://welearn.sflep.com/test/test.aspx?taskid={taskid}&cid={cid}", timeout=60000)
        else:
            log("  打开测试页 (缓存 URL)...")
            page.goto(url, timeout=60000)
        time.sleep(10)

        # 检查登录状态
        if "login" in page.url.lower():
            log("❌ 登录失效。可能原因：")
            log("  1. 所有测试都已完成，无法获取新 wlToken")
            log("  2. 缓存的测试 URL 已过期")
            log("  请从 welearn 课程页面点击测试获取新链接，或在启动器中更新 WeTest URL")
            input("按回车退出...")
            return

        log(f"  ✅ 已登录")


        # 加载扫描脚本
        js_path = os.path.join(SCRIPT_DIR, "scan_page.js")
        if os.path.exists(js_path):
            with open(js_path, "r", encoding="utf-8") as f:
                scan_js = f.read()
        else:
            log("❌ 找不到 scan_page.js")
            context.close()
            return

        # 处理所有 Part
        part_count = page.evaluate("() => document.querySelectorAll('.partDiv, [id^=part]').length")
        if part_count == 0: part_count = 1
        log(f"[4] 检测到 {part_count} 个 Part")

        success = 0
        for part_num in range(1, part_count + 1):
            log(f"\n📘 Part {part_num}/{part_count}")
            log("━" * 40)

            # 切换到当前 Part
            if part_count > 1:
                page.evaluate("""(num) => {
                    document.querySelectorAll('.partDiv').forEach(d => d.style.display = 'none');
                    var target = document.getElementById('part' + num);
                    if (target) target.style.display = 'block';
                    var tab = document.getElementById('aPart' + num);
                    if (tab) { tab.click(); tab.parentElement.classList.add('active'); }
                    if (typeof curPartNum !== 'undefined') curPartNum = num;
                    try { SelPart(num); } catch(e) {}
                }""", part_num)
                time.sleep(1)

            # 扫描题目
            log("扫描题目...")
            scan_result = page.evaluate(scan_js)
            text_inputs = scan_result.get("textInputs", [])
            radio_qs = scan_result.get("radios", [])
            select_qs = scan_result.get("selectBoxes", [])
            clickable_qs = scan_result.get("clickableOptions", [])
            passage = scan_result.get("passage", "")

            total = len(text_inputs) + len(radio_qs) + len(select_qs) + len(clickable_qs)
            log(f"  填空: {len(text_inputs)} | 选择: {len(radio_qs)} | 下拉: {len(select_qs)} | 点选: {len(clickable_qs)}")

            if total == 0:
                log("  ⚠️ 未扫描到题目")
                continue

            # ===== 填空题 =====
            fill_tasks = []
            for qi, q in enumerate(text_inputs):
                q_text = q.get("text", "")
                if not q_text or len(q_text) < 3: continue
                q_text = re.sub(r'^\d{1,3}[\.、\)\s]+', '', q_text).strip()
                qtype = q.get('qtype', '')

                # 翻译检测
                is_translation = any(kw in qtype.lower() for kw in ['writing', 'translation', 'translate', '翻译', '中译英', '英译中'])
                is_fill = any(kw in q_text for kw in ['填空', 'fill', 'blank', '括号', 'correct form'])
                has_cn = any('\u4e00' <= c <= '\u9fff' for c in q_text)

                if not is_fill and not is_translation and has_cn and passage:
                    is_translation = True
                elif not is_fill and not is_translation and not has_cn:
                    paren_match = re.search(r'[（(]([a-zA-Z,\s]+)[）)]', q_text)
                    if paren_match:
                        hint_content = paren_match.group(1).strip()
                        if ',' not in hint_content and ' ' not in hint_content.strip():
                            is_fill = True

                ctx_text = passage[:3000] if passage else ""

                if is_translation:
                    is_en_to_cn = any(kw in q_text.lower() for kw in ['into chinese', '英译中', '英译汉', '用中文', 'to chinese'])
                    is_cn_to_en = any(kw in q_text for kw in ['中译英', '汉译英', 'into english', '用英文', 'to english'])
                    if not is_en_to_cn and not is_cn_to_en:
                        clean_for_detect = re.sub(r'[（(][^）)]*[）)]', '', q_text)
                        cn_chars = sum(1 for c in clean_for_detect if '\u4e00' <= c <= '\u9fff')
                        en_chars = sum(1 for c in clean_for_detect if c.isascii() and c.isalpha())
                        is_en_to_cn = en_chars > cn_chars
                        is_cn_to_en = cn_chars >= en_chars

                    if is_en_to_cn:
                        system = "你是英译中专家。将英文翻译成地道、自然的中文。只输出中文翻译结果，不要解释。"
                        prompt = (f"【上下文】\n{ctx_text}\n\n" if ctx_text else "") + f"请将以下英文翻译成中文：\n\n{q_text}\n\n注意：只输出中文翻译。"
                    else:
                        system = "You are a translator. Translate Chinese to English."
                        hints = re.findall(r'[（(]([a-zA-Z,\s]+)[）)]', q_text)
                        hint_str = f" Required words: {hints[0]}." if hints else ""
                        clean_text = re.sub(r'[（(][a-zA-Z,\s]+[）)]', '', q_text).strip()
                        clean_text = re.sub(r'^\d{1,3}[\.、\)\s]+', '', clean_text).strip()
                        prompt = f"Translate to English.{hint_str}\n\nChinese: {clean_text}\nEnglish:"
                elif is_fill:
                    system = "你是英语语法专家。题目中括号里的单词是需要变换形式的原词，不是选项。根据句子语法，将括号中的单词变成正确的形式。只输出变换后的单词，严禁输出A/B/C/D等字母。"
                    prompt = (f"【上下文】\n{ctx_text}\n\n" if ctx_text else "") + f"【题目】\n{q_text}\n\n将括号中的单词变换为正确形式填入空格。只输出变换后的一个单词或短语。"
                else:
                    system = "你是英语考试专家。仔细阅读题目和上下文，给出最准确的答案。必须给出答案。只输出最终答案，不要解释。"
                    prompt = (f"【上下文】\n{ctx_text}\n\n" if ctx_text else "") + f"【题目】\n{q_text}"

                fill_tasks.append((qi, prompt, system, is_translation, is_cn_to_en if is_translation else False, q_text))

            # 并行调用 AI
            if fill_tasks:
                log(f"  并行请求 {len(fill_tasks)} 个填空题...")
                def _do_fill(task):
                    qi, prompt, system, is_trans, is_cn2en, q_text = task
                    raw = call_ai(prompt, system)
                    ans = extract_fill_answer(raw)
                    if ans and len(ans) == 1 and ans.upper() in 'ABCD':
                        raw = call_ai(prompt + "\n\n注意：答案不是A/B/C/D选项，请直接输出变换后的单词。", system)
                        ans = extract_fill_answer(raw)
                    if is_trans and is_cn2en and ans:
                        hints = re.findall(r'[（(]([a-zA-Z,\s]+)[）)]', q_text)
                        hint_words = [w.strip().lower() for h in hints for w in h.split(',')]
                        ans_lower = ans.lower().strip()
                        is_just_hints = False
                        if hint_words:
                            ans_no_hints = ans_lower
                            for hw in hint_words: ans_no_hints = ans_no_hints.replace(hw, '')
                            if len(ans_no_hints.replace(',', '').replace('.', '').replace(' ', '').strip()) < 3:
                                is_just_hints = True
                        first_char = next((c for c in ans if not c.isspace()), '') if ans else ''
                        if is_just_hints or ('\u4e00' <= first_char <= '\u9fff'):
                            clean_text2 = re.sub(r'[（(][^）)]*[）)]', '', q_text).strip()
                            clean_text2 = re.sub(r'^\d{1,3}[\.、\)\s]+', '', clean_text2).strip()
                            raw = call_ai(f"Translate this Chinese sentence to English. You must write a complete English sentence. Required words: {', '.join(hint_words)}.\n\nChinese: {clean_text2}\nEnglish:", "You are a translator. Write a complete English sentence.")
                            ans = extract_fill_answer(raw)
                    if not ans:
                        raw = call_ai(prompt + "\n\n注意：你必须给出答案，不能留空。", system)
                        ans = extract_fill_answer(raw)
                    return qi, ans

                fill_answers = {}
                with ThreadPoolExecutor(max_workers=5) as ex:
                    for qi, ans in ex.map(_do_fill, fill_tasks):
                        fill_answers[qi] = ans
                        log(f"    填空[{qi+1}] ✅ {ans[:50]}")

            # ===== 选择题 =====
            radio_tasks = []
            for rq in radio_qs:
                q_text = rq.get("question", "")
                options = rq.get("options", [])
                name = rq.get("name", "")
                if not name or not options: continue
                def _clean_opt(t):
                    return re.sub(r'^[A-D][\)\.\s]+', '', t)
                opt_str = "\n".join([f"{chr(65+i)}. {_clean_opt(opt.get('text',''))}" for i, opt in enumerate(options)])
                system = "你是英语考试专家。仔细分析每个选项，排除明显错误的，选择最准确的答案。只输出选项字母。"
                prompt = ""
                if passage: prompt += f"【文章】\n{passage[:3000]}\n\n"
                if q_text: prompt += f"【题目】\n{q_text}\n\n"
                prompt += f"【选项】\n{opt_str}\n\n选出最恰当的答案。只输出选项字母（如A）。"
                radio_tasks.append((name, prompt, system, len(options), q_text, opt_str))

            if radio_tasks:
                log(f"  并行请求 {len(radio_tasks)} 个选择题...")
                def _do_radio(task):
                    name, prompt, system, n, q_text, opt_str = task
                    # 打印题目和选项用于调试
                    if name in ['rd_16', 'rd_17', 'rd_18', 'rd_19', 'rd_20']:
                        log(f"    [{name}] q={q_text[:80]}")
                        log(f"    [{name}] opts={opt_str[:100]}")
                    raw = call_ai(prompt, system)
                    letter = extract_choice_letter(raw, n)
                    return name, letter

                radio_answers = {}
                with ThreadPoolExecutor(max_workers=5) as ex:
                    for name, letter in ex.map(_do_radio, radio_tasks):
                        if letter:
                            radio_answers[name] = ord(letter[0]) - ord('A')
                            log(f"    选择[{name}] ✅ {letter}")

            # ===== 填写答案 =====
            log("\n📝 填写答案...")
            filled = 0
            for qi, q in enumerate(text_inputs):
                if qi not in fill_answers: continue
                ans = fill_answers[qi]
                if not ans: continue
                el_id = q.get("id", "")
                el_name = q.get("name", "")
                iframe_idx = q.get("iframe", -1)
                try:
                    # 用 Playwright fill() 模拟真实键盘输入
                    if iframe_idx >= 0:
                        frame = page.frames[iframe_idx + 1]
                        el = frame.query_selector(f'#{el_id}') or frame.query_selector(f'[name="{el_name}"]')
                    else:
                        el = page.query_selector(f'#{el_id}') or page.query_selector(f'[name="{el_name}"]')
                    if el:
                        el.click()
                        time.sleep(0.3)
                        # 先清空
                        el.evaluate('e => e.value = ""')
                        el.type(ans, delay=5)  # 逐字输入，模拟真实打字
                        time.sleep(0.3)
                        el.press('Tab')
                        time.sleep(0.2)
                        filled += 1
                        if qi >= 5:  # 只打印翻译题的详细信息
                            log(f"    填空[{qi+1}] ✅ id={el_id} name={el_name} ans_len={len(ans)}")
                except Exception as e:
                    log(f"    填入失败[{qi+1}]: {e}")

            # 选择题填入
            selected = 0
            for rq in radio_qs:
                name = rq.get("name", "")
                if name not in radio_answers: continue
                idx = radio_answers[name]
                try:
                    radios = page.query_selector_all(f'input[name="{name}"]')
                    if idx < len(radios):
                        radios[idx].click()
                        selected += 1
                except Exception as e:
                    log(f"    选择填入失败[{name}]: {e}")

            log(f"  ✅ 填写 {filled} 个填空，{selected} 个选择")
            success += 1

        # 交卷
        auto_submit = os.environ.get("WELEARN_AUTO_SUBMIT", "0") == "1"
        if auto_submit:
            log("\n📤 自动交卷...")
            for sel in ["button:has-text('交卷')", "input[value*='交卷']", ".btn-submit"]:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click()
                    log("  ✅ 已点击交卷")
                    break
            time.sleep(3)
            for sel in ["button:has-text('确定')", "button:has-text('确认')"]:
                btn = page.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click()
                    break
            time.sleep(3)
            log("  ✅ 交卷完成！")
        else:
            log("\n⏸️ 手动模式。请在浏览器中手动交卷，交卷后按回车退出...")
            input()

        context.close()
        log("\n✅ 完成！")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        print(f"\n❌ 程序出错: {e}")
        traceback.print_exc()
    input("\n按回车退出...")
