import sys
def _excepthook(type, value, tb):
    import traceback
    traceback.print_exception(type, value, tb)
    input("\n程序出错，按回车退出...")
sys.excepthook = _excepthook

"""
Chapter Test 自动答题 v11-fix1
================================
修复：
1. 填空题：题目提取更精准，prompt 按题型分类，答案解析更强
2. 选择题：支持 Wetest 的 div/li 模拟 radio，AI 返回格式解析更健壮
3. 交卷前校验：检查答案完整性，空题补答
"""
import sys, os, time, json, re
from concurrent.futures import ThreadPoolExecutor, as_completed

# Windows 控制台 UTF-8 支持
try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except: pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ========== 配置（请修改为你的信息）==========
API_KEY = os.environ.get("DEEPSEEK_API_KEY", "sk-你的key")
CID = os.environ.get("WELEARN_CID", "208")
USERNAME = os.environ.get("WELEARN_USERNAME", "")
PASSWORD = os.environ.get("WELEARN_PASSWORD", "")

from urllib.parse import parse_qs, urlparse
import requests as req
from requests.adapters import HTTPAdapter
from urllib3.util.ssl_ import create_urllib3_context
import ssl
from playwright.sync_api import sync_playwright
from core.crypto import generate_cipher_text


class TLSAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        ctx = create_urllib3_context()
        ctx.set_ciphers('DEFAULT:@SECLEVEL=1')
        ctx.minimum_version = ssl.TLSVersion.TLSv1
        kwargs['ssl_context'] = ctx
        return super().init_poolmanager(*args, **kwargs)


def sso_login(u, p):
    sess = req.Session()
    sess.mount('https://', TLSAdapter(max_retries=3))
    sess.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
    r = sess.get("https://welearn.sflep.com/user/prelogin.aspx?loginret=http://welearn.sflep.com/user/loginredirect.aspx", timeout=60)
    if r.status_code != 200: return None, f"预登录失败: {r.status_code}"
    parts = r.url.split("%26")
    if len(parts) < 7: return None, "URL 解析失败"
    cc = parts[4].split("%3D")[1]; st = parts[6].split("%3D")[1]
    rturl = (f"/connect/authorize/callback?client_id=welearn_web&redirect_uri=https%3A%2F%2Fwelearn.sflep.com%2Fsignin-sflep"
             f"&response_type=code&scope=openid%20profile%20email%20phone%20address"
             f"&code_challenge={cc}&code_challenge_method=S256&state={st}"
             f"&x-client-SKU=ID_NET472&x-client-ver=6.32.1.0")
    enpwd = generate_cipher_text(p)
    r = sess.post("https://sso.sflep.com/idsvr/account/login",
        data={"rturl": rturl, "account": u, "pwd": enpwd[0], "ts": enpwd[1]}, timeout=60)
    if r.status_code != 200: return None, f"登录请求失败: {r.status_code}"
    j = r.json()
    if j.get("code") == 1: return None, "账号或密码错误"
    if j.get("code") != 0: return None, f"登录失败({j.get('code')})"
    try: sess.get("https://welearn.sflep.com/user/prelogin.aspx?loginret=http://welearn.sflep.com/user/loginredirect.aspx", timeout=60)
    except: pass
    return sess, "OK"


def log(m): print(f"[{time.strftime('%H:%M:%S')}] {m}")


# ========== AI 调用（带重试 + 答案解析）==========

def call_ai(prompt, system="你是一位英语考试专家。仔细分析题目，结合上下文，给出最准确的答案。必须给出答案，不能留空。", max_retries=2):
    """调用 DeepSeek API，带重试"""
    for attempt in range(max_retries + 1):
        try:
            r = req.post("https://api.deepseek.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
                json={"model": "deepseek-chat",
                      "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                      "temperature": 0.1, "max_tokens": 800},
                timeout=60)
            if r.status_code == 200:
                return r.json()["choices"][0]["message"]["content"].strip()
            elif r.status_code == 429:
                time.sleep(3 * (attempt + 1))  # 限流，等待后重试
                continue
            else:
                log(f"   ⚠️ API {r.status_code}: {r.text[:100]}")
        except Exception as e:
            if attempt < max_retries:
                time.sleep(2)
                continue
            log(f"   ⚠️ AI 错误: {e}")
    return ""


def extract_choice_letter(text, num_options=4):
    """从 AI 回答中提取选项字母"""
    if not text:
        return None
    text = text.strip()
    max_letter = chr(ord('A') + min(num_options - 1, 25))

    # 纯字母匹配
    pure = re.findall(rf'\b([{max_letter}])\b', text.upper())
    if pure:
        return ''.join(sorted(set(pure)))

    # "答案是X" 格式
    m = re.search(rf'(?:答案|选|选择|answer)[是为：:\s]*([{max_letter}])', text, re.IGNORECASE)
    if m:
        return m.group(1).upper()

    # 开头字母
    m = re.match(rf'\s*\(?([{max_letter}])\)?[\.\)）]', text)
    if m:
        return m.group(1).upper()

    # 兜底：第一个有效字母
    for ch in text.upper():
        if 'A' <= ch <= max_letter:
            return ch
    return None


def extract_fill_answer(text):
    """从 AI 回答中提取填空答案"""
    if not text:
        return ""
    text = text.strip()
    # 去掉 markdown
    text = re.sub(r'```[\s\S]*?```', '', text)
    text = re.sub(r'`([^`]*)`', r'\1', text)
    text = re.sub(r'\*{1,2}([^*]*)\*{1,2}', r'\1', text)
    text = text.strip('"\'""' + "''")
    # 去掉答案前缀
    text = re.sub(r'^(?:答案[是为：:]?\s*|answer[：:\s]?|the answer is\s*)', '', text, flags=re.IGNORECASE).strip()
    # 去掉开头的题号
    text = re.sub(r'^\d{1,3}[\.、\)\s]+', '', text).strip()
    # 去掉尾部句号
    text = text.rstrip('.').strip()
    # 去掉括号内的原文提示
    text = re.sub(r'\s*[（(][^）)]*[）)]$', '', text).strip()
    # 只取第一行
    if '\n' in text:
        first_line = text.split('\n')[0].strip()
        if first_line and len(first_line) < 200:
            text = first_line
    return text.strip()


# ========== 主流程 ==========

log("=" * 50)
log("SSO 登录...")
session, msg = sso_login(USERNAME, PASSWORD)
if not session:
    log(f"❌ {msg}"); input("退出..."); sys.exit(1)
log(f"✅ 成功, {len(list(session.cookies))} cookies")

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    ctx = browser.new_context(viewport={"width": 1280, "height": 900})
    page = ctx.new_page()

    # 注入 cookies
    log("注入 cookies...")
    for c in session.cookies:
        try:
            ctx.add_cookies([{"name": c.name, "value": c.value, "domain": c.domain.lstrip("."),
                              "path": c.path or "/", "httpOnly": True, "secure": c.secure or False}])
        except: pass

    # 去课程页
    log("前往课程...")
    for attempt in range(3):
        try:
            page.goto(f"https://welearn.sflep.com/student/course_info.aspx?cid={CID}", timeout=120000)
            break
        except:
            log(f"重试 {attempt+1}..."); time.sleep(5)
    time.sleep(3)
    log(f"页面: {page.url[:70]}")

    if "login" in page.url.lower():
        log("被踢到登录页，请手动登录")
        input("登录后按回车...")
        page.goto(f"https://welearn.sflep.com/student/course_info.aspx?cid={CID}", timeout=120000)
        time.sleep(3)

    # 移除弹窗
    page.evaluate("""() => {
        var m = document.getElementById('activatePopModal');
        if(m){m.remove()}
        document.querySelectorAll('.modal-backdrop').forEach(b=>b.remove())
    }""")
    time.sleep(1)

    # 点任务
    try: page.click("a[href='#mb2']", timeout=5000)
    except: page.evaluate("document.querySelector('a[href=\"#mb2\"]')?.click()")
    time.sleep(2)

    # 找测试
    tests = page.evaluate("""() => {
        const tasks = [];
        document.querySelectorAll('a[href*="StartTaskClassTest"]').forEach(a => {
            const m = a.getAttribute('href').match(/StartTaskClassTest\\((\\d+)\\)/);
            if(!m) return;
            const p = a.closest('.list-group-item,li,[class*="task"]');
            const txt = p?p.textContent:a.textContent;
            const nm = txt.match(/Chapter Test (\\d+)/i);
            tasks.push({taskId:m[1], name:nm?'Chapter Test '+nm[1]:'Test '+m[1]});
        });
        return tasks;
    }""")
    log(f"✅ {len(tests)} 个测试")
    for t in tests: log(f"   {t['name']}")

    success, fail = 0, 0

    for ti, t in enumerate(tests):
        log(f"\n{'─'*40}\n[{ti+1}/{len(tests)}] {t['name']}\n{'─'*40}")

        # 开新页面
        wp = None
        try:
            with ctx.expect_page(timeout=15000) as p_info:
                page.evaluate(f"StartTaskClassTest({t['taskId']})")
            wp = p_info.value
            wp.wait_for_load_state()
        except:
            time.sleep(5)
            for p2 in ctx.pages:
                if "wetest" in p2.url: wp = p2; break
            if not wp and "wetest" in page.url: wp = page

        if not wp or "wetest" not in wp.url:
            log("❌ 跳转失败"); fail += 1; continue

        log(f"✅ {wp.url[:60]}...")
        time.sleep(3)

        # ============================================================
        # 第零步：检测 Part 数量
        # ============================================================
        part_count = wp.evaluate("""() => {
            const parts = document.querySelectorAll('#ulParts li a[id^="aPart"]');
            return parts.length || 1;
        }""")
        log(f"检测到 {part_count} 个 Part")

        for part_num in range(1, part_count + 1):
            log(f"\n{'━'*40}")
            log(f"📘 Part {part_num}/{part_count}")
            log(f"{'━'*40}")

            # 切换到当前 Part — 强制显示目标 partDiv
            if part_count > 1:
                wp.evaluate("""(num) => {
                    // 隐藏所有 partDiv
                    document.querySelectorAll('.partDiv').forEach(d => d.style.display = 'none');
                    // 显示目标 partDiv
                    var target = document.getElementById('part' + num);
                    if (target) target.style.display = 'block';
                    // 点击 tab 激活
                    var tab = document.getElementById('aPart' + num);
                    if (tab) { tab.click(); tab.parentElement.classList.add('active'); }
                    // 更新全局变量
                    if (typeof curPartNum !== 'undefined') curPartNum = num;
                    // 也尝试调用原生切换
                    try { SelPart(num); } catch(e) {}
                }""", part_num)
                time.sleep(1)
                cur = wp.evaluate("() => typeof curPartNum !== 'undefined' ? curPartNum : 0")
                log(f"已切换到 Part {cur}")

            # ============================================================
            # 第一步：扫描题目 — 更全面的 DOM 提取
            # ============================================================
            log("扫描题目...")
            page_data = wp.evaluate(open(os.path.join(SCRIPT_DIR, "scan_page.js"), encoding="utf-8").read())

            text_inputs = page_data.get("textInputs", [])
            radio_qs = page_data.get("radios", [])
            select_qs = page_data.get("selectBoxes", [])
            clickable_qs = page_data.get("allQuestions", [])
            passage = page_data.get("passage", "")
            debug_passage = page_data.get("debugPassage", "")

            total_qs = len(text_inputs) + len(radio_qs) + len(select_qs) + len(clickable_qs)
            log(f"   填空/文本: {len(text_inputs)} | 选择(radio): {len(radio_qs)} | "
            f"选择(下拉): {len(select_qs)} | 选择(点击): {len(clickable_qs)} | 总计: {total_qs}")
            # 调试：输出页面所有 input 信息
            debug_info = page_data.get("debug", [])
            log(f"   [调试] 页面共 {len(debug_info)} 个 input/textarea:")
            for d in debug_info:
                log(f"      #{d['idx']} {d['tag']} type={d['type']} id='{d['id']}' name='{d['name']}' cls='{d['cls'][:40]}' vis={d['visible']} parent='{d['parent'][:40]}'")
            if passage:
                log(f"   阅读文章: {len(passage)} 字符")
            log(f"   [passage调试] 提取结果: {debug_passage[:100]}")

            # 调试：打印所有题目文本
            for ti2, q in enumerate(text_inputs):
                log(f"   [填空{ti2+1}] qnum={q.get('qnum',0)} qtype={q.get('qtype','')} text={q.get('text','')[:120]}")
            for ri, r in enumerate(radio_qs[:5]):
                log(f"   [选择{ri+1}] name={r.get('name','')} q={r.get('question','')[:80]} opts={[o.get('text','')[:30] for o in r.get('options',[])]}")

            if total_qs == 0:
                log("❌ 没找到任何题目")
                if wp != page: wp.close()
                fail += 1; continue

            # ============================================================
            # 第二步：AI 答题（按题型分类处理）
            # ============================================================
            log("\n🤖 AI 答题...")
            fill_answers = {}       # {index: answer_text}
            radio_answers = {}      # {name: letter}
            select_answers = {}     # {index: value}
            clickable_answers = {}  # {groupKey: option_index}

            # 2a. 填空题 — 并行请求
            fill_tasks = []  # [(qi, prompt, system)]
            for qi, q in enumerate(text_inputs):
                q_text = q.get("text", "")
                if not q_text or len(q_text) < 3:
                    continue
                # 去掉开头的题号 (如 "56." "56、" "56 " 等)
                q_text = re.sub(r'^\d{1,3}[\.、\)\s]+', '', q_text).strip()
                qtype = q.get('qtype', '')
                qcls = q.get('cls', '')
                is_translation = 'translation' in qtype.lower() or 'translate' in qtype.lower() or 'translation' in qcls.lower() or 'writing' in qtype.lower() or any(kw in q_text for kw in [
                    '翻译', 'Translate', 'translate', '中译英', '英译中', 'Translation', 'translation',
                    '英译汉', '汉译英', '把下列', '译成英语', '译成中文', '翻译成',
                    'rendered into', 'put into English', 'into Chinese', 'into chinese',
                    'into English', 'into english', 'into中文', 'into英文',
                    '汉译英', '中翻英', '英翻中',
                    'Chinese translation', 'Chinese Translation',
                    'Translate the following', 'translate the following',
                    'Put the following', 'put the following',
                    'Render the following', 'render the following',
                    'Turn the following', 'turn the following',
                    'Write in Chinese', 'write in Chinese',
                    '用中文', '用英文', '中文翻译', '英文翻译',
                ])
                is_fill = any(kw in q_text for kw in ['填空', 'fill', 'blank', '括号', 'correct form'])
                has_cn = any('\u4e00' <= c <= '\u9fff' for c in q_text)
                # 含中文的题目优先判断为翻译题（不管括号里有几个词）
                if not is_fill and not is_translation and has_cn and passage:
                    is_translation = True
                    log(f"   [检测] qi={qi} 补充识别为翻译题(含中文+有passage)")
                # 不含中文的括号题才是填空题（如 (socialize)）
                elif not is_fill and not is_translation and not has_cn:
                    paren_match = re.search(r'[（(]([a-zA-Z,\s]+)[）)]', q_text)
                    if paren_match:
                        hint_content = paren_match.group(1).strip()
                        if ',' not in hint_content and ' ' not in hint_content.strip():
                            is_fill = True
                log(f"   [检测] qi={qi} is_translation={is_translation} is_fill={is_fill} qtype={qtype}")
                ctx_text = passage[:3000] if passage else ""

                if is_translation:
                    is_en_to_cn = any(kw in q_text.lower() for kw in ['into chinese', 'into中文', '英译中', '英译汉', '英翻中', '用中文', '中文翻译', 'to chinese'])
                    is_cn_to_en = any(kw in q_text for kw in ['中译英', '汉译英', '中翻英', 'into english', 'into英文', '用英文', '英文翻译', 'to english'])
                    if not is_en_to_cn and not is_cn_to_en:
                        # 去掉括号中的提示词再统计字符
                        clean_for_detect = re.sub(r'[（(][^）)]*[）)]', '', q_text)
                        cn_chars = sum(1 for c in clean_for_detect if '\u4e00' <= c <= '\u9fff')
                        en_chars = sum(1 for c in clean_for_detect if c.isascii() and c.isalpha())
                        is_en_to_cn = en_chars > cn_chars
                        is_cn_to_en = cn_chars >= en_chars
                        log(f"   [翻译调试] 原始文本={q_text[:120]} clean={clean_for_detect[:60]} cn={cn_chars} en={en_chars} 判定={'en→cn' if is_en_to_cn else 'cn→en'}")
                    direction = 'en→cn' if is_en_to_cn else 'cn→en'
                    log(f"   [翻译] 方向={direction} 文本={q_text[:80]}")
                    if is_en_to_cn:
                        system = "你是英译中专家。将英文翻译成地道、自然的中文。只输出中文翻译结果，不要解释，不要加引号。"
                        prompt = (f"【上下文】\n{ctx_text}\n\n" if ctx_text else "") + f"请将以下英文翻译成中文：\n\n{q_text}\n\n注意：只输出中文翻译，不要输出英文原文。"
                    else:
                        system = "You are a translator. Translate Chinese to English."
                        # 提取括号中的提示词
                        hints = re.findall(r'[（(]([a-zA-Z,\s]+)[）)]', q_text)
                        hint_str = f" Required words: {hints[0]}." if hints else ""
                        clean_text = re.sub(r'[（(][a-zA-Z,\s]+[）)]', '', q_text).strip()
                        # 去掉开头的题号
                        clean_text = re.sub(r'^\d{1,3}[\.、\)\s]+', '', clean_text).strip()
                        prompt = f"Translate to English.{hint_str}\n\nExample:\nChinese: 经济增长促进了社会发展。\nEnglish: Economic growth has promoted social development.\n\nChinese: {clean_text}\nEnglish:"
                elif is_fill:
                    system = "你是英语语法专家。题目中括号里的单词是需要变换形式的原词，不是选项。根据句子语法，将括号中的单词变成正确的形式。只输出变换后的单词，严禁输出A/B/C/D等字母。"
                    prompt = (f"【上下文】\n{ctx_text}\n\n" if ctx_text else "") + f"【题目】\n{q_text}\n\n将括号中的单词变换为正确形式填入空格。注意：1)看清单复数 2)注意时态一致 3)考虑词性变换(名词/动词/形容词/副词)。只输出变换后的一个单词或短语，不要输出字母。"
                else:
                    system = "你是英语考试专家。仔细阅读题目和上下文，给出最准确的答案。必须给出答案，不能留空。只输出最终答案，不要解释。"
                    prompt = (f"【上下文】\n{ctx_text}\n\n" if ctx_text else "") + f"【题目】\n{q_text}"
                fill_tasks.append((qi, prompt, system, is_translation, is_cn_to_en if is_translation else False, q_text))

            # 并行调用 AI
            log(f"   并行请求 {len(fill_tasks)} 个填空题...")
            def _do_fill(task):
                qi, prompt, system, is_trans, is_cn2en, q_text = task
                # 翻译题调试日志
                if is_trans and is_cn2en:
                    hints = re.findall(r'[（(]([a-zA-Z,\s]+)[）)]', q_text)
                    clean = re.sub(r'[（(][a-zA-Z,\s]+[）)]', '', q_text).strip()
                    log(f"   [翻译调试] 原文={clean[:60]} 提示词={hints}")
                raw = call_ai(prompt, system)
                if is_trans and is_cn2en:
                    log(f"   [翻译调试] AI原始返回={raw[:80]}")
                ans = extract_fill_answer(raw)
                # 如果答案是单个字母(A/B/C/D)，说明AI误解了，重试
                if ans and len(ans) == 1 and ans.upper() in 'ABCD':
                    raw = call_ai(prompt + "\n\n注意：答案不是A/B/C/D选项，而是要将括号中的单词变换形式后填入空格。例如：(crime) -> crimes, (distant) -> distance。请直接输出变换后的单词。", system)
                    ans = extract_fill_answer(raw)
                # 中译英时，检查返回是否只是提示词
                if is_trans and is_cn2en and ans:
                    hints = re.findall(r'[（(]([a-zA-Z,\s]+)[）)]', q_text)
                    hint_words = [w.strip().lower() for h in hints for w in h.split(',')]
                    ans_lower = ans.lower().strip()
                    # 如果答案只是提示词（没有完整句子），重试
                    is_just_hints = False
                    if hint_words:
                        ans_no_hints = ans_lower
                        for hw in hint_words:
                            ans_no_hints = ans_no_hints.replace(hw, '')
                        # 去掉提示词后如果只剩标点和空格，说明只是提示词
                        if len(ans_no_hints.replace(',', '').replace('.', '').replace(' ', '').strip()) < 3:
                            is_just_hints = True
                    first_char = next((c for c in ans if not c.isspace()), '') if ans else ''
                    if is_just_hints or ('\u4e00' <= first_char <= '\u9fff'):
                        clean_text2 = re.sub(r'[（(][^）)]*[）)]', '', q_text).strip()
                        clean_text2 = re.sub(r'^\d{1,3}[\.、\)\s]+', '', clean_text2).strip()
                        raw = call_ai(f"Translate this Chinese sentence to English. You must write a complete English sentence. Required words: {', '.join(hint_words)}.\n\nChinese: {clean_text2}\nEnglish:", "You are a translator. Write a complete English sentence.")
                        ans = extract_fill_answer(raw)
                        log(f"   [翻译调试] 重试后返回={ans[:80]}")
                if not ans:
                    raw = call_ai(prompt + "\n\n注意：你必须给出答案，不能留空。直接输出答案。", system)
                    ans = extract_fill_answer(raw)
                return qi, ans

            with ThreadPoolExecutor(max_workers=5) as ex:
                for qi, ans in ex.map(_do_fill, fill_tasks):
                    if ans:
                        fill_answers[qi] = ans
                        log(f"   填空[{qi+1}] ✅ {ans[:60]}")
                    else:
                        log(f"   填空[{qi+1}] ⚠️ 未获取到答案")

            # 2b. 原生 radio 选择题 — 并行请求
            radio_tasks = []  # [(name, prompt, system, num_options)]
            for rq in radio_qs:
                q_text = rq.get("question", "")
                options = rq.get("options", [])
                name = rq.get("name", "")
                if not name or not options:
                    continue
                opt_str = "\n".join([f"{chr(65+i)}. {opt.get('text','')}" for i, opt in enumerate(options)])
                system = "你是英语考试专家。仔细分析每个选项，排除明显错误的，选择最准确的答案。必须给出答案。只输出选项字母。"
                prompt = ""
                if passage:
                    prompt += f"【文章】\n{passage[:3000]}\n\n"
                if q_text:
                    prompt += f"【题目】\n{q_text}\n\n"
                prompt += f"【选项】\n{opt_str}\n\n仔细分析每个选项的含义和用法区别，选出最恰当的答案。只输出选项字母（如A）。"
                radio_tasks.append((name, prompt, system, len(options)))

            log(f"   并行请求 {len(radio_tasks)} 个选择题...")
            def _do_radio(task):
                name, prompt, system, n = task
                raw = call_ai(prompt, system)
                letter = extract_choice_letter(raw, n)
                return name, letter, raw, prompt[:200]

            with ThreadPoolExecutor(max_workers=5) as ex:
                for name, letter, raw, prompt_preview in ex.map(_do_radio, radio_tasks):
                    if letter:
                        radio_answers[name] = ord(letter[0]) - ord('A')
                        log(f"   选择[{name}] ✅ {letter} | AI原始返回={raw[:60]}")
                    else:
                        log(f"   选择[{name}] ⚠️ AI返回: {raw[:60]}")

            # 2c. 下拉选择题 — 并行请求
            select_tasks = []  # [(idx, prompt, system, options)]
            for sq in select_qs:
                q_text = sq.get("question", "")
                options = sq.get("options", [])
                idx = sq.get("index", -1)
                opt_str = "\n".join([f"{opt['value']}. {opt['text']}" for opt in options])
                system = "你是英语考试专家。只输出选项对应的值或字母，不要解释。"
                prompt = f"【题目】\n{q_text}\n\n【选项】\n{opt_str}\n\n只输出正确选项的值。"
                select_tasks.append((idx, prompt, system, options))

            log(f"   并行请求 {len(select_tasks)} 个下拉题...")
            def _do_select(task):
                idx, prompt, system, options = task
                raw = call_ai(prompt, system)
                matched = None
                for opt in options:
                    if opt['value'].upper() in raw.upper() or opt['text'][:10] in raw:
                        matched = opt['value']
                        break
                if not matched:
                    letter = extract_choice_letter(raw, len(options))
                    if letter and letter[0].upper() <= chr(ord('A') + len(options) - 1):
                        matched = options[ord(letter[0]) - ord('A')]['value']
                return idx, matched, raw

            with ThreadPoolExecutor(max_workers=5) as ex:
                for idx, matched, raw in ex.map(_do_select, select_tasks):
                    if matched:
                        select_answers[idx] = matched
                        log(f"   下拉[{idx}] ✅ {matched}")
                    else:
                        log(f"   下拉[{idx}] ⚠️ AI返回: {raw[:40]}")

            # 2d. 可点击选项选择题 — 并行请求
            click_tasks = []  # [(group_key, prompt, system, num_options)]
            for cq in clickable_qs:
                q_text = cq.get("question", "")
                options = cq.get("options", [])
                group_key = cq.get("groupKey", "")
                opt_str = "\n".join([f"{chr(65+i)}. {opt.get('text','')}" for i, opt in enumerate(options)])
                system = "你是英语考试专家。仔细分析每个选项，排除明显错误的，选择最准确的答案。必须给出答案。只输出选项字母。"
                prompt = ""
                if passage:
                    prompt += f"【文章】\n{passage[:3000]}\n\n"
                prompt += f"【题目】\n{q_text}\n\n【选项】\n{opt_str}\n\n仔细分析每个选项，选出最恰当的答案。只输出选项字母（如A）。"
                click_tasks.append((group_key, prompt, system, len(options)))

            log(f"   并行请求 {len(click_tasks)} 个点选题...")
            def _do_click(task):
                group_key, prompt, system, n = task
                raw = call_ai(prompt, system)
                letter = extract_choice_letter(raw, n)
                return group_key, letter

            with ThreadPoolExecutor(max_workers=5) as ex:
                for group_key, letter in ex.map(_do_click, click_tasks):
                    if letter:
                        clickable_answers[group_key] = ord(letter[0]) - ord('A')
                        log(f"   点选[{group_key[:15]}] ✅ {letter}")

            # ============================================================
            # 第三步：填写答案到页面
            # ============================================================

            # 3a. 填空题填写
            if fill_answers:
                log(f"\n📝 填写 {len(fill_answers)} 个填空题...")
            filled = 0
            for qi, ans in fill_answers.items():
                if not ans:
                    continue
                try:
                    # 用题目文本匹配正确的输入框，而不是按全局索引
                    q_info = text_inputs[qi] if qi < len(text_inputs) else None
                    input_id = q_info.get('id', '') if q_info else ''
                    input_name = q_info.get('name', '') if q_info else ''

                    qnum_val = q_info.get('qnum', 0) if q_info else 0
                    if qnum_val:
                        result = wp.evaluate(f"""(args) => {{
                            const el = document.querySelector('input[data-qnum="' + args.qnum + '"], textarea[data-qnum="' + args.qnum + '"]');
                            if (!el) return 'not_found';
                            el.scrollIntoView({{behavior:'instant', block:'center'}});
                            el.focus();
                            el.value = args.val;
                            el.dispatchEvent(new Event('input', {{bubbles:true}}));
                            el.dispatchEvent(new Event('change', {{bubbles:true}}));
                            return 'ok';
                        }}""", {"qnum": qnum_val, "val": ans})
                    elif input_id:
                        # 用 id 定位
                        result = wp.evaluate(f"""(args) => {{
                            const el = document.getElementById(args.id);
                            if (!el) return 'not_found';
                            el.scrollIntoView({{behavior:'instant', block:'center'}});
                            el.focus();
                            el.value = args.val;
                            el.dispatchEvent(new Event('input', {{bubbles:true}}));
                            el.dispatchEvent(new Event('change', {{bubbles:true}}));
                            return 'ok';
                        }}""", {"id": input_id, "val": ans})
                    elif input_name:
                        # 用 name 定位
                        result = wp.evaluate(f"""(args) => {{
                            const el = document.querySelector('input[name="' + args.name + '"], textarea[name="' + args.name + '"]');
                            if (!el) return 'not_found';
                            el.scrollIntoView({{behavior:'instant', block:'center'}});
                            el.focus();
                            el.value = args.val;
                            el.dispatchEvent(new Event('input', {{bubbles:true}}));
                            el.dispatchEvent(new Event('change', {{bubbles:true}}));
                            return 'ok';
                        }}""", {"name": input_name, "val": ans})
                    else:
                        # 兜底：用题目容器内的 input 定位
                        q_text = q_info.get('text', '')[:80] if q_info else ''
                        result = wp.evaluate(f"""(args) => {{
                            // 找题目容器
                            const containers = document.querySelectorAll('.question-item, .exam-item, .q-item, [class*="question"], [class*="fill"]');
                            for (const c of containers) {{
                                if (c.innerText.includes(args.qtext)) {{
                                    const el = c.querySelector('input[type="text"], input:not([type]), textarea');
                                    if (el) {{
                                        el.scrollIntoView({{behavior:'instant', block:'center'}});
                                        el.focus();
                                        el.value = args.val;
                                        el.dispatchEvent(new Event('input', {{bubbles:true}}));
                                        el.dispatchEvent(new Event('change', {{bubbles:true}}));
                                        return 'ok';
                                    }}
                                }}
                            }}
                            return 'not_found';
                        }}""", {"qtext": q_text, "val": ans})

                    if result == 'not_found':
                        log(f"   ⚠️ 填[{qi+1}]找不到输入框")
                    else:
                        filled += 1
                        log(f"   填[{qi+1}] ✅ {ans[:40]}")
                except Exception as e:
                    log(f"   ⚠️ 填[{qi+1}]失败: {str(e)[:50]}")
            log(f"   ✅ 已填 {filled}/{len(fill_answers)}")

            # 3b. 原生 radio 选择
            if radio_answers:
                log(f"\n🔘 选择 {len(radio_answers)} 道 radio 选择题...")
            selected = 0
            for name, opt_idx in radio_answers.items():
                try:
                    radios = wp.locator(f'input[name="{name}"]')
                    count = radios.count()
                    if opt_idx < count:
                        radios.nth(opt_idx).scroll_into_view_if_needed()
                        time.sleep(0.2)
                        radios.nth(opt_idx).check(force=True)
                        selected += 1
                    else:
                        log(f"   ⚠️ {name} 索引 {opt_idx} 超出范围 {count}")
                except Exception as e:
                    try:
                        # JS 备用方案
                        wp.evaluate(f"""(args) => {{
                            const radios = document.querySelectorAll('input[name="{name}"]');
                            if (radios[args.idx]) {{
                                radios[args.idx].checked = true;
                                radios[args.idx].click();
                                radios[args.idx].dispatchEvent(new Event('change', {{bubbles:true}}));
                            }}
                        }}""", {"idx": opt_idx})
                        selected += 1
                    except:
                        log(f"   ⚠️ 选择[{name}]失败")
            log(f"   ✅ 已选 {selected}/{len(radio_answers)}")

            # 3c. 下拉选择
            if select_answers:
                log(f"\n📋 填写 {len(select_answers)} 个下拉选择题...")
            for idx, value in select_answers.items():
                try:
                    sel = wp.locator('select').nth(idx)
                    sel.scroll_into_view_if_needed()
                    sel.select_option(value=value)
                except:
                    try:
                        wp.evaluate(f"""(args) => {{
                            const sel = document.querySelectorAll('select')[args.idx];
                            if (sel) {{
                                sel.value = args.val;
                                sel.dispatchEvent(new Event('change', {{bubbles:true}}));
                            }}
                        }}""", {"idx": idx, "val": value})
                    except: pass

            # 3d. 可点击选项
            if clickable_answers:
                log(f"\n🖱️ 点击 {len(clickable_answers)} 个可点击选项...")
            for group_key, opt_idx in clickable_answers.items():
                try:
                    # 找到对应的题目区域
                    options_els = wp.locator(
                        f'[class*="option"], [role="option"], li[data-value], .choice-item'
                    )
                    count = options_els.count()
                    if opt_idx < count:
                        options_els.nth(opt_idx).scroll_into_view_if_needed()
                        time.sleep(0.2)
                        options_els.nth(opt_idx).click()
                except:
                    pass

        # Part 循环结束
        log(f"\n✅ 所有 {part_count} 个 Part 处理完毕")

        # ============================================================
        # 第四步：交卷前检查
        # ============================================================
        log("\n🔍 交卷前检查...")
        check = wp.evaluate("""() => {
            const inputs = document.querySelectorAll('input[type="text"]:not([type="hidden"]), textarea');
            let empty = 0, filled = 0;
            inputs.forEach(el => {
                if (el.offsetParent !== null) {  // 只检查可见的
                    if (el.value && el.value.trim()) filled++;
                    else empty++;
                }
            });
            const radios = document.querySelectorAll('input[type="radio"]:checked');
            return {emptyInputs: empty, filledInputs: filled, selectedRadios: radios.length};
        }""")
        log(f"   文本: {check['filledInputs']}已填 / {check['emptyInputs']}未填 | "
            f"选择: {check['selectedRadios']}已选")

        # ============================================================
        # 第五步：确认交卷
        # ============================================================
        log("\n📤 准备交卷...")
        try:
            ans_summary = f"填空: {len(fill_answers)} | 选择: {len(radio_answers)} | 下拉: {len(select_answers)} | 点选: {len(clickable_answers)}"
            log(f"   {ans_summary}")
        except: ans_summary = ""

        # 检查是否自动交卷（启动器通过环境变量控制）
        auto_submit = os.environ.get("WELEARN_AUTO_SUBMIT", "0") == "1"
        if auto_submit:
            log("   ✅ 自动交卷模式")
        else:
            log("   ⏸️ 手动模式。请在浏览器中手动交卷...")
            log(f"   [调试] wp.url={wp.url if wp else 'None'} page.url={page.url}")
            # 等待交卷成功提示出现，然后自动点返回
            submitted_detected = False
            for _ in range(300):  # 最多等 5 分钟
                try:
                    current_url = wp.url if wp else page.url
                    # 已经回到课程页了（检查 URL 路径，不是参数）
                    if "/course_info" in current_url and "wetest" not in current_url:
                        log(f"   [调试] 检测到课程页: {current_url[:60]}")
                        log("   ✅ 已返回课程页")
                        submitted_detected = True
                        break
                    # 检测交卷成功提示（必须先看到成功提示才点返回）
                    page_text = wp.evaluate("() => document.body.innerText") if wp else ""
                    if "交卷成功" in page_text or "提交成功" in page_text or "successfully" in page_text.lower():
                        if not submitted_detected:
                            log("   ✅ 检测到交卷成功")
                            submitted_detected = True
                        # 点击返回按钮
                        for sel in ["a:has-text('返回')", "button:has-text('返回')", "a[href*='course_info']"]:
                            btn = wp.query_selector(sel)
                            if btn and btn.is_visible():
                                btn.click()
                                log("   ✅ 已自动点击返回")
                                time.sleep(2)
                                break
                except: pass
                time.sleep(1)
            log("   ✅ 检测到已返回课程页，继续下一个测试")
            success += 1
            time.sleep(2)
            page.evaluate("document.getElementById('activatePopModal')?.remove(); document.querySelectorAll('.modal-backdrop').forEach(b=>b.remove())")
            try: page.click("a[href='#mb2']", timeout=5000)
            except: page.evaluate("document.querySelector('a[href=\"#mb2\"]')?.click()")
            time.sleep(2)
            continue
        time.sleep(2)
        submitted = False
        try:
            for sel in [
                "button:has-text('交卷')", "input[value*='交卷']", "a:has-text('交卷')",
                ".btn-submit", "[class*='submit']", "[class*='handin']", "[class*='finish']"
            ]:
                btn = wp.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click()
                    submitted = True
                    log("   ✅ 已点击交卷")
                    break
            if not submitted:
                wp.evaluate("""() => {
                    const btns = document.querySelectorAll('button, a, input[type="button"]');
                    for(const b of btns){
                        if(b.innerText.includes('交卷') || b.value?.includes('交卷') ||
                           b.innerText.includes('提交') || b.innerText.includes('Submit')) {
                            b.click(); return true;
                        }
                    }
                    return false;
                }""")
                submitted = True
                log("   ✅ 已点击交卷(JS)")
            time.sleep(3)
            # 确认对话框
            for sel in ["button:has-text('确定')", "button:has-text('确认')", ".dialog-confirm", ".confirm-btn"]:
                btn = wp.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click()
                    log("   ✅ 已确认交卷")
                    break
            time.sleep(3)
            # 点击"返回"按钮
            for sel in ["a:has-text('返回')", "button:has-text('返回')", ".btn-back", "a[href*='course_info']"]:
                btn = wp.query_selector(sel)
                if btn and btn.is_visible():
                    btn.click()
                    log("   ✅ 已点击返回")
                    break
            else:
                # JS 方式查找返回按钮
                wp.evaluate("""() => {
                    const btns = document.querySelectorAll('a, button, input');
                    for(const b of btns){
                        if(b.innerText.includes('返回') || b.value?.includes('返回') ||
                           b.innerText.includes('Back') || b.innerText.includes('back')) {
                            b.click(); return true;
                        }
                    }
                    return false;
                }""")
                log("   ✅ 已点击返回(JS)")
            time.sleep(3)
            success += 1
        except Exception as e:
            log(f"   ⚠️ 交卷异常: {e}")
            fail += 1

        # 回课程页
        if wp != page:
            try: wp.close()
            except: pass
        try:
            page.goto(f"https://welearn.sflep.com/student/course_info.aspx?cid={CID}", timeout=60000)
        except:
            page.evaluate(f"window.location='https://welearn.sflep.com/student/course_info.aspx?cid={CID}'")
            time.sleep(8)
        time.sleep(2)
        page.evaluate("document.getElementById('activatePopModal')?.remove(); document.querySelectorAll('.modal-backdrop').forEach(b=>b.remove())")
        try: page.click("a[href='#mb2']", timeout=5000)
        except: page.evaluate("document.querySelector('a[href=\"#mb2\"]')?.click()")
        time.sleep(2)

    try:
        log(f"\n{'='*50}")
        log(f"✅ 完成！成功: {success}/{len(tests)}  失败: {fail}/{len(tests)}")
        input("按回车关闭浏览器...")
        browser.close()
    except Exception as e:
        import traceback
        traceback.print_exc()
        input("\n程序出错，按回车退出...")
