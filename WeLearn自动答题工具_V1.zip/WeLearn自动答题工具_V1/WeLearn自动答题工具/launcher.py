"""
WeLearn 自动答题启动器
======================
带 GUI 界面，填写 API Key 和信息后一键启动脚本。
双击 launcher.py 即可打开。
"""
import os
import sys
import json
import time
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading
import requests as _requests
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
import ssl

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(SCRIPT_DIR, ".launcher_config.json")

# 导入 SSO 加密
sys.path.insert(0, SCRIPT_DIR)
from core.crypto import generate_cipher_text


class TLSAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        ctx = ssl.create_default_context()
        ctx.set_ciphers("DEFAULT@SECLEVEL=1")
        kwargs["ssl_context"] = ctx
        super().init_poolmanager(*args, **kwargs)


def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_config(cfg):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def sso_login(username, password):
    """SSO 登录，返回 (session, message)"""
    sess = _requests.Session()
    sess.mount("https://", TLSAdapter(max_retries=3))
    sess.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
    try:
        r = sess.get("https://welearn.sflep.com/user/prelogin.aspx?loginret=http://welearn.sflep.com/user/loginredirect.aspx", timeout=60)
        if r.status_code != 200:
            return None, f"预登录失败: {r.status_code}"
        parts = r.url.split("%26")
        if len(parts) < 7:
            return None, "URL 解析失败"
        cc = parts[4].split("%3D")[1]
        st = parts[6].split("%3D")[1]
        rturl = (
            f"/connect/authorize/callback?client_id=welearn_web&redirect_uri=https%3A%2F%2Fwelearn.sflep.com%2Fsignin-sflep"
            f"&response_type=code&scope=openid%20profile%20email%20phone%20address"
            f"&code_challenge={cc}&code_challenge_method=S256&state={st}"
            f"&x-client-SKU=ID_NET472&x-client-ver=6.32.1.0"
        )
        enpwd = generate_cipher_text(password)
        r = sess.post(
            "https://sso.sflep.com/idsvr/account/login",
            data={"rturl": rturl, "account": username, "pwd": enpwd[0], "ts": enpwd[1]},
            timeout=60,
        )
        if r.status_code != 200:
            return None, f"登录请求失败: {r.status_code}"
        j = r.json()
        if j.get("code") == 1:
            return None, "账号或密码错误"
        if j.get("code") != 0:
            return None, f"登录失败({j.get('code')})"
        try:
            sess.get("https://welearn.sflep.com/user/prelogin.aspx?loginret=http://welearn.sflep.com/user/loginredirect.aspx", timeout=60)
        except:
            pass
        return sess, "OK"
    except Exception as e:
        return None, f"登录异常: {e}"


def get_courses(session):
    """获取课程列表，返回 [(cid, name), ...]"""
    try:
        r = session.get(
            "https://welearn.sflep.com/ajax/authCourse.aspx?action=gmc",
            headers={"Referer": "https://welearn.sflep.com/2019/student/index.aspx"},
            timeout=15,
        )
        if r.status_code != 200:
            return []
        data = r.json()
        clist = data.get("clist", [])
        courses = []
        for c in clist:
            cid = str(c.get("cid", ""))
            name = c.get("coursename", c.get("name", f"课程{cid}"))
            if cid:
                courses.append((cid, name))
        return courses
    except:
        return []


class WeLearnLauncher:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("WeLearn 自动答题启动器")
        self.root.geometry("620x580")
        self.root.resizable(False, False)

        cfg = load_config()
        self.courses = []  # [(cid, name), ...]

        # ---- 样式 ----
        style = ttk.Style()
        style.configure("Title.TLabel", font=("微软雅黑", 16, "bold"))
        style.configure("Section.TLabelframe.Label", font=("微软雅黑", 10, "bold"))
        style.configure("Launch.TButton", font=("微软雅黑", 11, "bold"))

        # ---- 标题 ----
        ttk.Label(self.root, text="🎓 WeLearn 自动答题", style="Title.TLabel").pack(pady=(10, 5))

        # ---- API Key 区域 ----
        frame_api = ttk.LabelFrame(self.root, text="🔑 DeepSeek API Key", style="Section.TLabelframe", padding=8)
        frame_api.pack(fill="x", padx=15, pady=5)

        self.api_key_var = tk.StringVar(value=cfg.get("api_key", ""))
        self.api_entry = ttk.Entry(frame_api, textvariable=self.api_key_var, show="•", width=60)
        self.api_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))

        self.show_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(frame_api, text="显示", variable=self.show_var,
                        command=self._toggle_show).pack(side="right")

        # ---- Chapter Test 区域 ----
        frame_ch = ttk.LabelFrame(self.root, text="📘 Chapter Test 设置", style="Section.TLabelframe", padding=8)
        frame_ch.pack(fill="x", padx=15, pady=5)

        # 用户名密码 + 获取课程按钮
        row0 = ttk.Frame(frame_ch)
        row0.pack(fill="x", pady=2)
        ttk.Label(row0, text="用户名:").pack(side="left")
        self.user_var = tk.StringVar(value=cfg.get("username", ""))
        ttk.Entry(row0, textvariable=self.user_var, width=20).pack(side="left", padx=(5, 10))

        ttk.Label(row0, text="密码:").pack(side="left")
        self.pass_var = tk.StringVar(value=cfg.get("password", ""))
        ttk.Entry(row0, textvariable=self.pass_var, show="•", width=15).pack(side="left", padx=(5, 10))

        self.login_btn = ttk.Button(row0, text="🔍 获取课程", command=self._fetch_courses)
        self.login_btn.pack(side="left", padx=5)

        self.login_status = ttk.Label(row0, text="", foreground="gray")
        self.login_status.pack(side="left", padx=5)

        # 课程选择（下拉菜单）
        row1 = ttk.Frame(frame_ch)
        row1.pack(fill="x", pady=2)
        ttk.Label(row1, text="选择课程:").pack(side="left")
        self.course_var = tk.StringVar(value="")
        self.course_combo = ttk.Combobox(row1, textvariable=self.course_var, width=50, state="readonly")
        self.course_combo.pack(side="left", padx=(5, 5))
        self.course_combo.set("请先点击「获取课程」")
        self.cid_label = ttk.Label(row1, text="", foreground="gray")
        self.cid_label.pack(side="left", padx=5)

        # ---- Wetest 区域 ----
        frame_wt = ttk.LabelFrame(self.root, text="📗 Wetest 设置", style="Section.TLabelframe", padding=8)
        frame_wt.pack(fill="x", padx=15, pady=5)

        ttk.Label(frame_wt, text="测试 URL:").pack(anchor="w")
        self.url_var = tk.StringVar(value=cfg.get("wetest_url", ""))
        ttk.Entry(frame_wt, textvariable=self.url_var, width=75).pack(fill="x", pady=(2, 0))

        # ---- 选项 ----
        frame_opt = ttk.Frame(self.root)
        frame_opt.pack(fill="x", padx=15, pady=5)
        self.auto_submit_var = tk.BooleanVar(value=cfg.get("auto_submit", True))
        ttk.Checkbutton(frame_opt, text="✅ 自动交卷（开启后答完自动提交，关闭则等待手动交卷）",
                        variable=self.auto_submit_var).pack(anchor="w")

        # ---- 按钮 ----
        frame_btn = ttk.Frame(self.root)
        frame_btn.pack(fill="x", padx=15, pady=10)

        ttk.Button(frame_btn, text="📘 启动 Chapter Test", style="Launch.TButton",
                   command=lambda: self._launch("chapter")).pack(side="left", expand=True, fill="x", padx=(0, 5))
        ttk.Button(frame_btn, text="📗 启动 Wetest", style="Launch.TButton",
                   command=lambda: self._launch("wetest")).pack(side="right", expand=True, fill="x", padx=(5, 0))

        # ---- 日志区域 ----
        frame_log = ttk.LabelFrame(self.root, text="📋 运行日志", style="Section.TLabelframe", padding=5)
        frame_log.pack(fill="both", expand=True, padx=15, pady=(0, 10))
        self.log_text = scrolledtext.ScrolledText(frame_log, height=6, font=("Consolas", 9),
                                                   state="disabled", bg="#1e1e1e", fg="#d4d4d4",
                                                   insertbackground="white")
        self.log_text.pack(fill="both", expand=True)

        self._log("就绪。填写信息后点击按钮启动。")

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.mainloop()

    def _toggle_show(self):
        self.api_entry.config(show="" if self.show_var.get() else "•")

    def _log(self, msg):
        self.log_text.config(state="normal")
        self.log_text.insert("end", f"[{_time()}] {msg}\n")
        self.log_text.see("end")
        self.log_text.config(state="disabled")

    def _save(self):
        save_config({
            "api_key": self.api_key_var.get().strip(),
            "username": self.user_var.get().strip(),
            "password": self.pass_var.get().strip(),
            "wetest_url": self.url_var.get().strip(),
            "auto_submit": self.auto_submit_var.get(),
            "last_course": self.course_combo.get(),
        })

    def _fetch_courses(self):
        """SSO 登录并获取课程列表"""
        user = self.user_var.get().strip()
        pwd = self.pass_var.get().strip()
        if not user or not pwd:
            messagebox.showwarning("缺少信息", "请先填写用户名和密码！")
            return

        self.login_btn.config(state="disabled")
        self.login_status.config(text="登录中...", foreground="blue")
        self._log("SSO 登录中...")

        def do_fetch():
            session, msg = sso_login(user, pwd)
            if not session:
                self.root.after(0, lambda: self._fetch_done(False, msg, []))
                return
            self.root.after(0, lambda: self._log("登录成功，获取课程列表..."))
            courses = get_courses(session)
            self.root.after(0, lambda: self._fetch_done(True, f"找到 {len(courses)} 门课程", courses))

        threading.Thread(target=do_fetch, daemon=True).start()

    def _fetch_done(self, success, msg, courses):
        """获取课程完成回调"""
        self.login_btn.config(state="normal")
        if success:
            self.courses = courses
            self.login_status.config(text=f"✅ {msg}", foreground="green")
            self._log(f"✅ {msg}")
            # 填充下拉菜单
            display = [f"{name} (CID:{cid})" for cid, name in courses]
            self.course_combo["values"] = display
            if display:
                self.course_combo.current(0)
                self._on_course_select(None)
            # 绑定选择事件
            self.course_combo.bind("<<ComboboxSelected>>", self._on_course_select)
        else:
            self.login_status.config(text=f"❌ {msg}", foreground="red")
            self._log(f"❌ {msg}")

    def _on_course_select(self, event):
        """课程选择变化"""
        idx = self.course_combo.current()
        if 0 <= idx < len(self.courses):
            cid, name = self.courses[idx]
            self.cid_label.config(text=f"CID: {cid}")

    def _get_selected_cid(self):
        """获取当前选中的 CID"""
        idx = self.course_combo.current()
        if 0 <= idx < len(self.courses):
            return self.courses[idx][0]
        return ""

    def _launch(self, mode):
        api_key = self.api_key_var.get().strip()
        if not api_key:
            messagebox.showwarning("缺少信息", "请先填写 DeepSeek API Key！")
            return

        self._save()

        env = os.environ.copy()
        env["DEEPSEEK_API_KEY"] = api_key
        env["WELEARN_AUTO_SUBMIT"] = "1" if self.auto_submit_var.get() else "0"
        env["WELEARN_USERNAME"] = self.user_var.get().strip()
        env["WELEARN_PASSWORD"] = self.pass_var.get().strip()

        if mode == "chapter":
            cid = self._get_selected_cid()
            user = self.user_var.get().strip()
            pwd = self.pass_var.get().strip()
            if not all([user, pwd]):
                messagebox.showwarning("缺少信息", "Chapter Test 需要填写用户名和密码！")
                return
            if not cid:
                messagebox.showwarning("缺少信息", "请先获取课程并选择一门课程！")
                return
            script = os.path.join(SCRIPT_DIR, "chapter_v11.py")
            args = [sys.executable, script]
            env["WELEARN_CID"] = cid
            env["WELEARN_USERNAME"] = user
            env["WELEARN_PASSWORD"] = pwd
            course_name = self.course_combo.get()
            self._log(f"启动 Chapter Test: {course_name}")
        else:
            url = self.url_var.get().strip()
            if not url:
                messagebox.showwarning("缺少信息", "Wetest 需要填写测试 URL！\n请从浏览器地址栏复制粘贴。")
                return
            if "testKey" not in url and "wetest" not in url:
                messagebox.showwarning("URL 格式错误", "请粘贴完整的 Wetest 测试 URL！\n格式: https://wetest.sflep.com/test/...?testKey=...")
                return
            script = os.path.join(SCRIPT_DIR, "wetest_auto.py")
            if not os.path.exists(script):
                messagebox.showerror("文件缺失", f"找不到脚本: {script}")
                return
            args = [sys.executable, script, url]
            self._log(f"启动 Wetest 自动答题...")
            self._log(f"URL: {url[:80]}...")

        self._log(f"脚本: {script}")
        self._log("新窗口将弹出，请在新窗口中操作。")

        def run():
            try:
                proc = subprocess.Popen(
                    args, env=env, cwd=SCRIPT_DIR,
                    creationflags=subprocess.CREATE_NEW_CONSOLE,
                )
                self._log(f"进程已启动 (PID={proc.pid})，请在新窗口中操作")
                proc.wait()
                if proc.returncode != 0:
                    self._log(f"⚠️ 脚本退出码: {proc.returncode}")
                else:
                    self._log("✅ 脚本执行完成")
            except Exception as e:
                self._log(f"启动失败: {e}")
                messagebox.showerror("启动失败", str(e))

        threading.Thread(target=run, daemon=True).start()

    def _on_close(self):
        self._save()
        self.root.destroy()


def _time():
    import datetime
    return datetime.datetime.now().strftime("%H:%M:%S")


if __name__ == "__main__":
    WeLearnLauncher()
