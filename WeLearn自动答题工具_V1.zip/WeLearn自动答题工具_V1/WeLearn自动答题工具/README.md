# WeLearn 自动答题工具

自动完成 WeLearn 平台的 Chapter Test 和 WeTest 测试，基于 DeepSeek AI 答题。

## 使用前提

- Windows 10/11
- Python 3.10 或更高版本（[下载](https://www.python.org/downloads/)）
- DeepSeek API Key（[获取](https://platform.deepseek.com/)）

## 使用方法

1. 解压整个文件夹
2. 双击 **`启动.bat`**
3. 首次会自动安装依赖（约 2-5 分钟），安装完成后自动重启
4. 填入你的 DeepSeek API Key 和相关信息
5. 点击按钮开始答题

## 功能

| 功能 | 说明 |
|------|------|
| 📘 Chapter Test | 输入课程 ID、用户名、密码，自动登录并完成所有测试 |
| 📗 WeTest | 粘贴测试链接，直接打开并自动答题 |

## 文件说明

```
├── 启动.bat            # 双击启动（首次自动安装依赖）
├── launcher.py         # GUI 启动器
├── chapter_v11.py      # Chapter Test 答题核心
├── wetest_auto.py      # WeTest 答题核心
├── scan_page.js        # 页面扫描脚本
├── core/               # 核心模块
└── requirements.txt    # Python 依赖清单
```

## 常见问题

**Q: 双击启动闪退？**
A: 右键用管理员身份运行，或检查 Python 是否安装正确。

**Q: AI 答题不准确？**
A: 目前准确率在持续优化中，填空题和选择题已做专门适配。

**Q: API Key 怎么获取？**
A: 注册 [DeepSeek 开放平台](https://platform.deepseek.com/)，创建 API Key 即可。
