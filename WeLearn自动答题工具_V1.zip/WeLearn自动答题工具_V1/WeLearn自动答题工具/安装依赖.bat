@echo off
chcp 65001 >nul 2>&1
title WeLearn
cd /d "%~dp0"

python --version >nul 2>&1
if errorlevel 1 goto no_python

python -c "import playwright, requests" >nul 2>&1
if errorlevel 1 goto install
goto launch

:no_python
echo [ERROR] Python not found!
echo Please install Python 3.10+ from https://www.python.org/downloads/
echo Check "Add Python to PATH" during installation.
pause
exit /b 1

:install
echo.
echo ==========================================
echo   First run - installing dependencies...
echo   The script will restart after install.
echo ==========================================
echo.

echo [1/2] Installing Python packages...
pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto pip_fail
echo      OK

echo [2/2] Installing Playwright browser...
python -m playwright install chromium
if errorlevel 1 goto pw_fail
echo      OK

python -c "import playwright, requests" >nul 2>&1
if errorlevel 1 goto verify_fail

echo.
echo ==========================================
echo   Done! Restarting...
echo ==========================================
echo.
timeout /t 2 >nul
cmd /c start "" "%~f0"
exit /b 0

:pip_fail
echo.
echo [ERROR] Failed to install Python packages!
echo Please check your network connection.
echo Or run manually: pip install -r requirements.txt
pause
exit /b 1

:pw_fail
echo.
echo [ERROR] Failed to install Playwright browser!
echo Please run manually: python -m playwright install chromium
pause
exit /b 1

:verify_fail
echo.
echo [ERROR] Dependencies installed but import failed.
echo Please restart your computer and try again.
pause
exit /b 1

:launch
python "%~dp0unified_launcher.py"
if errorlevel 1 goto launch_fail
exit /b 0

:launch_fail
echo.
echo Launch failed! Please check your Python environment.
pause
