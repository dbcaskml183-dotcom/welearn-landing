"""
SSO 登录密码加密模块
从 sso.sflep.com 的 common.js 中的 generateCipherText 函数逆向而来
"""
import time
import base64


def generate_cipher_text(password: str) -> tuple:
    """
    加密密码，返回 (encrypted_base64, timestamp)
    与 JS 版 generateCipherText 行为一致
    """
    T0 = int(time.time() * 1000)  # 毫秒时间戳
    P = password.encode("utf-8")
    V = (T0 >> 16) & 0xFF
    for byte in P:
        V ^= byte
    remainder = V % 100
    T1 = (T0 // 100) * 100 + remainder
    P1 = "".join(f"{byte & 0xFF:02x}" for byte in P)
    S = f"{T1}*{P1}"
    E = base64.b64encode(S.encode("utf-8")).decode("ascii")
    return E, T1
