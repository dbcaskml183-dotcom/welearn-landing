"""
DeepSeek AI 智能答题助手 v2
支持按题型分类生成 prompt，带答案解析和格式校验
"""
import os
import json
import re
import requests
from typing import Optional, Tuple, List, Dict


# ========== 全局配置 ==========
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_MODEL = "deepseek-chat"


def is_configured() -> bool:
    return bool(DEEPSEEK_API_KEY)


def set_api_key(api_key: str):
    global DEEPSEEK_API_KEY
    DEEPSEEK_API_KEY = api_key if api_key else ""


def set_api_url(url: str):
    global DEEPSEEK_API_URL
    DEEPSEEK_API_URL = url


def call_deepseek(
    messages: List[dict],
    temperature: float = 0.7,
    max_tokens: int = 4096,
    timeout: int = 120,
) -> Tuple[Optional[str], Optional[str]]:
    if not DEEPSEEK_API_KEY:
        return None, "未配置 API Key"

    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": DEEPSEEK_MODEL,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    try:
        resp = requests.post(DEEPSEEK_API_URL, headers=headers, json=payload, timeout=timeout)
        resp.raise_for_status()
        result = resp.json()
        content = result["choices"][0]["message"]["content"]
        return content, None
    except requests.exceptions.Timeout:
        return None, "API 请求超时"
    except requests.exceptions.ConnectionError:
        return None, "无法连接到 DeepSeek API"
    except requests.exceptions.HTTPError as e:
        return None, f"API 返回错误: {e}"
    except (KeyError, json.JSONDecodeError) as e:
        return None, f"API 响应解析失败: {e}"
    except Exception as e:
        return None, f"API 调用异常: {e}"


# ========== 答案解析工具 ==========

def extract_choice_letter(text: str, num_options: int = 4) -> Optional[str]:
    """
    从 AI 回答中提取选项字母。处理各种格式：
    - "A" / "B" / "C" / "D"
    - "答案是A" / "选B" / "The answer is C"
    - "A." / "A)" / "(A)"
    - "**A**" / "A. Because..."
    - 多选: "AB" / "A, C" / "AC"
    """
    if not text:
        return None
    text = text.strip()

    # 构造匹配范围 (A-D 或 A-对应选项数)
    max_letter = chr(ord('A') + num_options - 1) if num_options <= 26 else 'Z'

    # 优先匹配：纯字母（可能多选）
    pure = re.findall(rf'\b([{max_letter}])\b', text.upper())
    if pure:
        return ''.join(sorted(set(pure)))  # 去重排序

    # 匹配：答案是X / 选X
    m = re.search(rf'(?:答案|选|选择|answer)[是为：:\s]*([{max_letter}])', text, re.IGNORECASE)
    if m:
        return m.group(1).upper()

    # 匹配：开头第一个字母
    m = re.match(rf'\s*\(?([{max_letter}])\)?[\.\)）]', text)
    if m:
        return m.group(1).upper()

    # 最后兜底：第一个出现的有效字母
    for ch in text.upper():
        if 'A' <= ch <= max_letter:
            return ch

    return None


def extract_fill_answer(text: str) -> str:
    """
    从 AI 回答中提取填空答案。
    去掉 markdown 格式、多余解释、引号等。
    """
    if not text:
        return ""
    text = text.strip()

    # 去掉 markdown 代码块
    text = re.sub(r'```[\s\S]*?```', '', text)
    # 去掉行内代码
    text = re.sub(r'`([^`]*)`', r'\1', text)
    # 去掉加粗/斜体标记
    text = re.sub(r'\*{1,2}([^*]*)\*{1,2}', r'\1', text)
    # 去掉前后引号
    text = text.strip('"\'""''')
    # 去掉 "答案是：" / "Answer:" 等前缀
    text = re.sub(r'^(?:答案[是为：:]?\s*|answer[：:\s]?)', '', text, flags=re.IGNORECASE).strip()
    # 如果 AI 给了多行，只取第一行（通常是答案）
    if '\n' in text:
        first_line = text.split('\n')[0].strip()
        if first_line and len(first_line) < 200:  # 答案不应该太长
            text = first_line

    return text.strip()


# ========== 按题型生成 Prompt ==========

def generate_fill_prompt(question_text: str, context: str = "") -> List[dict]:
    """填空题 prompt"""
    system = (
        "你是英语考试专家。根据题目要求完成填空。\n"
        "规则：\n"
        "1. 如果题目说'用括号中单词的正确形式填空'，给出该单词的正确变形\n"
        "2. 如果是翻译题，给出完整翻译\n"
        "3. 如果是语法填空，根据上下文填入正确的词\n"
        "4. 只输出最终答案，不要解释，不要加引号，不要加'答案是'"
    )

    user_content = ""
    if context:
        user_content += f"【上下文/文章】\n{context[:2000]}\n\n"
    user_content += f"【题目】\n{question_text}"

    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user_content},
    ]


def generate_choice_prompt(question_text: str, options: List[Dict], context: str = "") -> List[dict]:
    """选择题 prompt"""
    system = (
        "你是英语考试专家。准确回答选择题。\n"
        "规则：\n"
        "1. 仔细分析每个选项\n"
        "2. 只输出选项字母（如 A 或 B 或 C 或 D），多选用逗号分隔（如 A,C）\n"
        "3. 不要输出解释，不要输出选项文字，只输出字母"
    )

    user_content = ""
    if context:
        user_content += f"【上下文/文章】\n{context[:2000]}\n\n"
    user_content += f"【题目】\n{question_text}\n\n【选项】\n"
    for i, opt in enumerate(options):
        label = opt.get("label") or opt.get("key") or chr(65 + i)
        text = opt.get("text") or opt.get("value") or ""
        user_content += f"{label}. {text}\n"

    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user_content},
    ]


def generate_translation_prompt(question_text: str, context: str = "") -> List[dict]:
    """翻译题 prompt"""
    system = (
        "你是翻译专家。完成中英互译。\n"
        "规则：\n"
        "1. 只输出翻译结果\n"
        "2. 保持原文的语气和风格\n"
        "3. 不要加解释"
    )
    user_content = ""
    if context:
        user_content += f"【上下文】\n{context[:1500]}\n\n"
    user_content += f"【待翻译内容】\n{question_text}"

    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user_content},
    ]


def generate_reading_prompt(question_text: str, options: List[Dict], passage: str) -> List[dict]:
    """阅读理解 prompt"""
    system = (
        "你是英语阅读理解专家。根据文章内容回答问题。\n"
        "规则：\n"
        "1. 仔细阅读文章，找到相关段落\n"
        "2. 如果是选择题，只输出选项字母\n"
        "3. 如果是填空/简答题，直接输出答案\n"
        "4. 不要输出解释"
    )

    user_content = f"【文章】\n{passage[:3000]}\n\n【题目】\n{question_text}\n"
    if options:
        user_content += "\n【选项】\n"
        for i, opt in enumerate(options):
            label = opt.get("label") or opt.get("key") or chr(65 + i)
            text = opt.get("text") or opt.get("value") or ""
            user_content += f"{label}. {text}\n"

    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user_content},
    ]


# ========== 智能答题函数 ==========

def answer_fill(question_text: str, context: str = "") -> Tuple[str, Optional[str]]:
    """回答填空题，返回 (答案, 错误)"""
    messages = generate_fill_prompt(question_text, context)
    result, error = call_deepseek(messages, temperature=0.15, max_tokens=300, timeout=60)
    if error:
        return "", error
    return extract_fill_answer(result), None


def answer_choice(question_text: str, options: List[Dict], context: str = "") -> Tuple[Optional[str], Optional[str]]:
    """回答选择题，返回 (选项字母, 错误)"""
    if not options:
        return None, "无选项"
    messages = generate_choice_prompt(question_text, options, context)
    result, error = call_deepseek(messages, temperature=0.15, max_tokens=100, timeout=60)
    if error:
        return None, error
    letter = extract_choice_letter(result, num_options=len(options))
    return letter, None


def answer_reading(question_text: str, options: List[Dict], passage: str) -> Tuple[str, Optional[str]]:
    """回答阅读理解，返回 (答案, 错误)"""
    messages = generate_reading_prompt(question_text, options, passage)
    result, error = call_deepseek(messages, temperature=0.15, max_tokens=500, timeout=60)
    if error:
        return "", error
    if options:
        letter = extract_choice_letter(result, num_options=len(options))
        return letter or extract_fill_answer(result), None
    return extract_fill_answer(result), None


def answer_translation(question_text: str, context: str = "") -> Tuple[str, Optional[str]]:
    """回答翻译题，返回 (翻译结果, 错误)"""
    messages = generate_translation_prompt(question_text, context)
    result, error = call_deepseek(messages, temperature=0.2, max_tokens=1000, timeout=60)
    if error:
        return "", error
    return extract_fill_answer(result), None


# ========== 通用接口（兼容旧代码） ==========

def generate_answers(questions_text: str) -> Tuple[Optional[str], Optional[str]]:
    messages = [
        {"role": "system", "content": "你是智能答题助手。准确回答问题。"},
        {"role": "user", "content": f"请回答以下问题：\n\n{questions_text[:8000]}"},
    ]
    return call_deepseek(messages, temperature=0.3, max_tokens=4096)


def analyze_course_text(text_content: str) -> Tuple[Optional[str], Optional[str]]:
    messages = [
        {"role": "system", "content": "你是课程学习助手。分析内容，提取关键知识点。用中文简洁输出。"},
        {"role": "user", "content": f"请分析：\n\n{text_content[:8000]}"},
    ]
    return call_deepseek(messages, temperature=0.3, max_tokens=2048)


def evaluate_assignment(assignment_text: str) -> Tuple[Optional[str], Optional[str]]:
    messages = [
        {"role": "system", "content": (
            "你是作业评估助手。分析内容，输出JSON：\n"
            '{"analysis":"分析说明","difficulty":"easy/medium/hard",'
            '"recommended_accuracy":85,"has_questions":true/false,"summary":"摘要"}'
        )},
        {"role": "user", "content": f"请评估：\n\n{assignment_text[:8000]}"},
    ]
    return call_deepseek(messages, temperature=0.2, max_tokens=2048)


def summarize_content(content_text: str) -> Tuple[Optional[str], Optional[str]]:
    messages = [
        {"role": "system", "content": "用1-2句话概括核心要点。用中文。"},
        {"role": "user", "content": f"请概括：\n\n{content_text[:4000]}"},
    ]
    return call_deepseek(messages, temperature=0.2, max_tokens=500)
