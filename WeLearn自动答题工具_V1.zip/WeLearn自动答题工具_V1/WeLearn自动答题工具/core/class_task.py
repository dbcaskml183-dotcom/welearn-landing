"""
WeLearn 班级任务处理模块 v3
直接从课程页面提取 Wetest 测试任务并完成
"""
import re
import time
import json
import requests
from typing import Tuple, List, Dict
from core.api import WeLearnClient


WETEST_BASE = "https://wetest.sflep.com"
WETEST_TIMEOUT = 30  # wetest 请求超时时间


def get_wetest_tasks_from_course(
    client: WeLearnClient, cid: str
) -> Tuple[bool, List[Dict], str]:
    """
    从课程页面中提取 wetest 测试任务

    参数:
        client: 已登录的 WeLearnClient
        cid: 课程 ID

    返回:
        (是否成功, 任务列表, 错误信息)
    """
    try:
        tasks = []
        page_headers = {
            "Referer": f"{client.BASE_URL}/2019/student/index.aspx",
            "X-Requested-With": "XMLHttpRequest",
        }

        # 方式1: 尝试从 js/ajax API 获取任务列表
        api_list = [
            f"{client.BASE_URL}/ajax/task.aspx?action=list&cid={cid}&_={int(time.time())}",
            f"{client.BASE_URL}/ajax/StudyStat.aspx?action=getClassTask&cid={cid}",
            f"{client.BASE_URL}/ajax/StudyStat.aspx?action=classTasks&cid={cid}",
            f"{client.BASE_URL}/ajax/StudyStat.aspx?action=getTasks&cid={cid}",
        ]

        for api_url in api_list:
            for retry in range(2):
                try:
                    resp = client.session.post(
                        api_url.split("?")[0],
                        data=api_url.split("?")[1] if "?" in api_url else "",
                        headers=page_headers,
                        timeout=15,
                    )
                    if resp.status_code == 200:
                        text = resp.text.strip()
                        if text.startswith("{"):
                            jd = resp.json()
                            parsed = _parse_task_json(jd)
                            if parsed:
                                return True, parsed, f"找到 {len(parsed)} 个测试"
                except Exception:
                    pass
                time.sleep(1)

        # 方式2: 从课程页面 HTML 中提取任务/测试信息
        url = f"{client.BASE_URL}/student/course_info.aspx?cid={cid}"
        for retry in range(3):
            try:
                resp = client.session.get(url, headers=page_headers, timeout=60)
                if resp.status_code == 200:
                    html = resp.text
                    # 在页面中搜索 wetest 链接
                    wetest_tasks = _extract_wetest_tasks_from_html(html)
                    if wetest_tasks:
                        return True, wetest_tasks, f"找到 {len(wetest_tasks)} 个测试"

                    # 在页面中搜索 testKey / task key 等关键词
                    keys = re.findall(r'["\'](testKey|taskId|tt_id)["\']\s*[:=]\s*["\']([^"\']+)["\']', html)
                    for k, v in keys:
                        tasks.append({"testKey": v, "wlToken": "", "url": "", "title": f"任务"})

                    keys2 = re.findall(r'testKey[=:]([a-zA-Z0-9_%+/=]+)', html)
                    for k in keys2:
                        if len(k) > 20:
                            tasks.append({"testKey": k, "wlToken": "", "url": "", "title": f"测试"})

                    if tasks:
                        return True, tasks, f"找到 {len(tasks)} 个测试"
                    break
            except Exception:
                pass
            time.sleep(2)

        # 方式3: 如果上面都没找到，尝试通过课程单元信息获取 SCO 中的测试
        # 获取课程单元，找出所有 "test" 相关的 SCO
        ok, course_data, _ = client.get_course_info(cid)
        if ok and course_data:
            uid = course_data.get("uid")
            classid = course_data.get("classid")
            units = course_data.get("units", [])
            for ui, unit in enumerate(units):
                ok2, leaves, _ = client.get_sco_leaves(cid, uid, classid, ui)
                if ok2:
                    for sco in leaves:
                        title = (sco.get("location") or "").lower()
                        if "test" in title or "测验" in title or "测试" in title or "考试" in title or "chapter" in title:
                            if "未" in sco.get("iscomplete", ""):
                                tasks.append({
                                    "testKey": sco.get("id", ""),
                                    "wlToken": "",
                                    "url": "",
                                    "title": sco.get("location", "测试"),
                                    "cid": cid,
                                    "uid": uid,
                                    "classid": classid,
                                    "scoid": sco.get("id"),
                                    "from_sco": True,
                                })

        if tasks:
            return True, tasks, f"找到 {len(tasks)} 个测试任务(来自课程单元)"

        return False, [], "未找到测试任务"

    except Exception as e:
        return False, [], f"获取课程页面异常: {str(e)}"


def _extract_wetest_tasks_from_html(html: str) -> List[Dict]:
    """从 HTML 中提取 wetest 测试任务"""
    if not html:
        return []

    from urllib.parse import unquote, parse_qs, urlparse

    full_url_pattern = r'(https?://wetest\.sflep\.com/test/welearnTest\.html[^"\'<>\s]+)'
    full_urls = re.findall(full_url_pattern, html)

    # 也搜索 URL 编码版本
    decoded_html = unquote(html)
    decoded_urls = re.findall(full_url_pattern, decoded_html)

    all_urls = set(full_urls + decoded_urls)
    tasks = []

    for link in all_urls:
        parsed = urlparse(link)
        params = parse_qs(parsed.query)
        test_key = params.get("testKey", [None])[0]
        wl_token = params.get("wlToken", [None])[0]
        if test_key and wl_token:
            tasks.append({
                "testKey": test_key,
                "wlToken": wl_token,
                "url": link,
                "title": f"测试任务",
            })

    return tasks


def _parse_task_json(data: dict) -> List[Dict]:
    """从 JSON API 响应中解析任务"""
    tasks = []
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        items = data.get("data", data.get("list", data.get("tasks", [data])))
    else:
        return tasks

    for item in items if isinstance(items, list) else [items]:
        if isinstance(item, dict):
            test_key = item.get("testKey") or item.get("test_key") or item.get("key")
            wl_token = item.get("wlToken") or item.get("token")
            if test_key:
                tasks.append({
                    "testKey": test_key,
                    "wlToken": wl_token or "",
                    "url": f"https://wetest.sflep.com/test/welearnTest.html?action=joinTest&source=welearn&testKey={test_key}&wlToken={wl_token or ''}",
                    "title": item.get("title", item.get("name", "测试任务")),
                })

    return tasks


def get_tasks_for_all_courses(
    client: WeLearnClient,
    progress_callback=None,
    stop_flag=None,
) -> Tuple[bool, List[Dict], str]:
    """
    获取所有课程中的 Wetest 测试任务

    参数:
        client: 已登录的 WeLearnClient
        progress_callback: 回调
        stop_flag: 停止标志

    返回:
        (是否成功, 任务列表, 错误信息)
    """
    all_tasks = []

    if progress_callback:
        progress_callback("info", "正在获取课程列表...")

    ok, courses, message = client.get_courses()
    if not ok or not courses:
        return False, [], f"获取课程失败: {message}"

    if progress_callback:
        progress_callback("info", f"找到 {len(courses)} 门课程，正在扫描班级任务...")

    for idx, course in enumerate(courses):
        if stop_flag and stop_flag():
            break

        cid = course.get("cid")
        course_name = course.get("name", f"课程{idx+1}")

        if progress_callback:
            progress_callback("course", f"[{idx+1}/{len(courses)}] {course_name}")

        for retry in range(3):
            if stop_flag and stop_flag():
                break
            ok, tasks, msg = get_wetest_tasks_from_course(client, cid)
            if ok and tasks:
                for t in tasks:
                    t["course_name"] = course_name
                    t["cid"] = cid
                    all_tasks.append(t)
                if progress_callback:
                    progress_callback("info", f"  找到 {len(tasks)} 个测试任务")
                break
            elif retry < 2:
                if progress_callback:
                    progress_callback("warn", f"  {msg}，重试...")
                time.sleep(2)

    return True, all_tasks, f"共找到 {len(all_tasks)} 个测试任务"


def process_wetest_test(
    task: Dict,
    progress_callback=None,
) -> Tuple[bool, str]:
    """
    处理 Wetest 测试 - 使用 DeepSeek AI 答题

    流程:
    1. 访问测试页面建立 wetest session (通过 wlToken 认证)
    2. 调用 initTest 获取题目
    3. 解析题目，调用 AI 生成答案
    4. 提交答案 (savePaper)

    参数:
        task: 任务信息 (需包含 testKey, wlToken, url)
        progress_callback: 回调

    返回:
        (是否成功, 状态消息)
    """
    import requests as req_lib

    test_key = task.get("testKey", "")
    wl_token = task.get("wlToken", "")
    full_url = task.get("url", "")
    course_name = task.get("course_name", "")

    if not test_key or not wl_token:
        return False, "缺少 testKey 或 wlToken"

    if progress_callback:
        progress_callback("task_start", f"[{course_name}] 认证测试系统...")

    wetest_api = f"{WETEST_BASE}/test/api/WelearnTest.aspx"

    try:
        # 第0步：创建独立的 wetest session
        # wetest.sflep.com 是独立域名，welearn 的 cookie 不通用
        ws = req_lib.Session()
        ws.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        })

        # 访问测试页面建立认证（携带 wlToken）
        auth_resp = ws.get(full_url, timeout=15)
        if auth_resp.status_code != 200:
            return False, f"认证失败: {auth_resp.status_code}"

        if progress_callback:
            progress_callback("info", f"  [{course_name}] 认证成功，加载测试...")

        # 第1步：调用 initTest 获取试卷
        headers = {
            "Referer": f"{WETEST_BASE}/test/welearnTest.html",
            "Content-Type": "application/json;charset=UTF-8",
        }

        resp = ws.post(
            wetest_api,
            headers=headers,
            json={},
            params={"action": "initTest", "testKey": test_key},
            timeout=30,
        )

        if resp.status_code != 200:
            return False, f"初始化测试失败: {resp.status_code}"

        try:
            result = resp.json()
        except Exception:
            return False, f"非 JSON 响应: {resp.text[:200]}"

        # 检查响应状态
        data = result
        if isinstance(result, dict):
            if result.get("status") == 1 and "data" in result:
                data = result["data"]
            elif result.get("status") == 0 or result.get("status") is False:
                return False, f"API 异常: {json.dumps(result, ensure_ascii=False)[:200]}"

        test_id = data.get("testId") or data.get("id")

        if data.get("isFinish"):
            if progress_callback:
                progress_callback("info", f"  [{course_name}] 测试已完成")
            return True, f"✅ [{course_name}] 测试已先前完成"

        # 获取题目列表
        questions = data.get("questions", []) or data.get("questionList", []) or data.get("items", [])

        if not questions:
            if progress_callback:
                progress_callback("info", f"  [{course_name}] 无题目数据")
            return True, f"✅ [{course_name}] 无需作答"

        if progress_callback:
            progress_callback("info", f"  [{course_name}] 共 {len(questions)} 道题")

        # 第2步：AI 答题（按题型分类处理）
        from core.ai_helper import (
            is_configured, call_deepseek,
            extract_choice_letter, extract_fill_answer,
            generate_fill_prompt, generate_choice_prompt,
        )

        answers = {}
        answered_count = 0

        if is_configured():
            for q_idx, question in enumerate(questions):
                if progress_callback:
                    progress_callback("info", f"  第 {q_idx+1}/{len(questions)} 题")

                q_id = question.get("id") or question.get("questionId") or question.get("key", "")
                q_text = question.get("title") or question.get("text") or question.get("content", "")
                options = question.get("options", []) or question.get("optionList", [])
                q_type = question.get("type", 0)

                if not q_text:
                    continue

                # 根据题型选择不同的 prompt 和解析策略
                if options and len(options) >= 2:
                    # 选择题：用专门的选择题 prompt
                    messages = generate_choice_prompt(q_text, options)
                    result_text, error = call_deepseek(messages, temperature=0.15, max_tokens=100)
                    if result_text:
                        letter = extract_choice_letter(result_text, num_options=len(options))
                        if letter:
                            answers[q_id] = letter
                            answered_count += 1
                        else:
                            # 兜底：存原始回答
                            answers[q_id] = result_text.strip()[:10]
                            answered_count += 1
                else:
                    # 填空/问答题：用专门的填空 prompt
                    messages = generate_fill_prompt(q_text)
                    result_text, error = call_deepseek(messages, temperature=0.15, max_tokens=300)
                    if result_text:
                        ans = extract_fill_answer(result_text)
                        if ans:
                            answers[q_id] = ans
                            answered_count += 1

                time.sleep(0.3)  # 防止限流

        if progress_callback:
            progress_callback("info", f"  [{course_name}] AI 回答了 {answered_count}/{len(questions)} 题")

        # 第3步：提交试卷
        if progress_callback:
            progress_callback("info", f"  [{course_name}] 提交试卷...")

        submit_data = {
            "testId": test_id,
            "partNum": "0",
            "Answers": answers if answers else {},
            "Submit": True,
            "ClientTime": time.strftime("%Y-%m-%d %H:%M:%S"),
        }

        resp = ws.post(
            f"{wetest_api}?action=savePaper&nocache={int(time.time()*1000)}",
            headers=headers,
            json=submit_data,
            timeout=30,
        )

        if resp.status_code == 200:
            return True, f"✅ [{course_name}] 测试完成 - AI 回答 {answered_count} 题"
        else:
            return False, f"❌ [{course_name}] 提交失败: {resp.status_code}"

    except Exception as e:
        return False, f"❌ [{course_name}] 异常: {str(e)}"


def process_all_tasks(
    client: WeLearnClient,
    progress_callback=None,
    stop_flag=None,
) -> Tuple[int, int]:
    """
    处理所有课程的班级测试任务

    流程:
    1. 扫描所有课程获取 Wetest 测试
    2. 逐测试 AI 答题并提交

    返回:
        (成功数, 失败数)
    """
    # 第1步：获取所有测试任务
    if progress_callback:
        progress_callback("info", "正在扫描课程中的班级测试任务...")

    ok, tasks, message = get_tasks_for_all_courses(
        client, progress_callback, stop_flag
    )

    if not ok or not tasks:
        if progress_callback:
            progress_callback("error", f"未找到班级测试: {message}")
        return 0, 1

    if progress_callback:
        progress_callback("info", f"\n开始处理 {len(tasks)} 个班级测试...")

    # 第2步：逐测试处理
    success_count = 0
    fail_count = 0

    for i, task in enumerate(tasks):
        if stop_flag and stop_flag():
            break

        course_name = task.get("course_name", "")
        title = task.get("title", f"任务{i+1}")

        if progress_callback:
            progress_callback("task_start", f"\n[{i+1}/{len(tasks)}] {course_name} - {title}")

        # 判断任务类型：有 wlToken 走 wetest，否则走 SCO 提交
        if task.get("from_sco"):
            # SCO 类型的测试任务 - 使用现有提交方式
            cid = task.get("cid")
            uid = task.get("uid")
            classid = task.get("classid")
            scoid = task.get("scoid")

            from core.ai_helper import is_configured
            accuracy = "85"
            if is_configured():
                accuracy = "90"

            w1_s, w1_f, w2_s, w2_f = client.submit_course_progress(
                cid, uid, classid, scoid, accuracy
            )

            if w1_s or w2_s:
                success_count += 1
                msg = f"✅ {title} - 完成 (正确率: {accuracy}%)"
            else:
                fail_count += 1
                msg = f"❌ {title} - 提交失败"

            if progress_callback:
                progress_callback("info" if w1_s or w2_s else "error", msg)
        else:
            # Wetest 类型的测试任务
            ok, message = process_wetest_test(task, progress_callback)
            if ok:
                success_count += 1
            else:
                fail_count += 1
            if progress_callback:
                progress_callback("info" if ok else "error", f"  {message}")

    return success_count, fail_count
