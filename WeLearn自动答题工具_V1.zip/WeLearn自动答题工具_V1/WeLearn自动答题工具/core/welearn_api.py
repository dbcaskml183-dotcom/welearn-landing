"""
WeLearn API 客户端
==================
直接通过 API 完成课程进度提交，不需要浏览器。
整合自 Auto_WeLearn-master 的 core/api.py + core/smart_study.py
"""
import re
import time
import json
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from typing import Dict, List, Optional, Tuple
from core.crypto import generate_cipher_text


class WeLearnClient:
    BASE_URL = "https://welearn.sflep.com"

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        retry = Retry(total=3, backoff_factor=0.5, status_forcelist=[500, 502, 503, 504])
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

    def login(self, username: str, password: str) -> Tuple[bool, str]:
        """SSO 登录"""
        try:
            r = self.session.get(
                f"{self.BASE_URL}/user/prelogin.aspx?loginret=http://welearn.sflep.com/user/loginredirect.aspx",
                timeout=60,
            )
            if r.status_code != 200:
                return False, f"预登录失败: {r.status_code}"
            parts = r.url.split("%26")
            if len(parts) < 7:
                return False, "URL 解析失败"
            cc = parts[4].split("%3D")[1]
            st = parts[6].split("%3D")[1]
            rturl = (
                f"/connect/authorize/callback?client_id=welearn_web"
                f"&redirect_uri=https%3A%2F%2Fwelearn.sflep.com%2Fsignin-sflep"
                f"&response_type=code&scope=openid%20profile%20email%20phone%20address"
                f"&code_challenge={cc}&code_challenge_method=S256&state={st}"
                f"&x-client-SKU=ID_NET472&x-client-ver=6.32.1.0"
            )
            enpwd = generate_cipher_text(password)
            r = self.session.post(
                "https://sso.sflep.com/idsvr/account/login",
                data={"rturl": rturl, "account": username, "pwd": enpwd[0], "ts": enpwd[1]},
                timeout=60,
            )
            if r.status_code != 200:
                return False, f"登录请求失败: {r.status_code}"
            j = r.json()
            if j.get("code") == 1:
                return False, "账号或密码错误"
            if j.get("code") != 0:
                return False, f"登录失败({j.get('code')})"
            try:
                self.session.get(
                    f"{self.BASE_URL}/user/prelogin.aspx?loginret=http://welearn.sflep.com/user/loginredirect.aspx",
                    timeout=60,
                )
            except:
                pass
            return True, "登录成功"
        except Exception as e:
            return False, f"登录异常: {e}"

    def get_courses(self) -> Tuple[bool, List[Dict], str]:
        """获取所有课程"""
        try:
            r = self.session.get(
                f"{self.BASE_URL}/ajax/authCourse.aspx?action=gmc",
                headers={"Referer": f"{self.BASE_URL}/2019/student/index.aspx"},
                timeout=15,
            )
            if r.status_code != 200:
                return False, [], f"获取课程失败: {r.status_code}"
            data = r.json()
            clist = data.get("clist", [])
            return True, clist, f"找到 {len(clist)} 门课程"
        except Exception as e:
            return False, [], f"获取课程异常: {e}"

    def get_course_info(self, cid: str) -> Tuple[bool, Optional[Dict], str]:
        """获取课程详情（uid, classid, units）"""
        for attempt in range(3):
            try:
                r = self.session.get(f"{self.BASE_URL}/student/course_info.aspx?cid={cid}", timeout=15)
                if r.status_code != 200:
                    return False, None, f"获取课程信息失败: {r.status_code}"
                uid_match = re.search(r'"uid":\s*(\d+),', r.text)
                classid_match = re.search(r'"classid":"(\w+)"', r.text)
                if not uid_match or not classid_match:
                    return False, None, "无法解析课程信息（可能需要先在网页上选课）"
                uid = uid_match.group(1)
                classid = classid_match.group(1)
                r = self.session.get(
                    f"{self.BASE_URL}/ajax/StudyStat.aspx",
                    params={"action": "courseunits", "cid": cid, "uid": uid},
                    headers={"Referer": f"{self.BASE_URL}/2019/student/course_info.aspx"},
                    timeout=15,
                )
                if r.status_code != 200:
                    return False, None, f"获取单元信息失败: {r.status_code}"
                data = r.json()
                if "info" not in data:
                    return False, None, "单元信息格式错误"
                return True, {"uid": uid, "classid": classid, "units": data["info"]}, "获取成功"
            except Exception as e:
                if attempt < 2:
                    time.sleep(1)
                    continue
                return False, None, f"获取课程信息异常: {e}"

    def get_sco_leaves(self, cid: str, uid: str, classid: str, unit_idx: int) -> Tuple[bool, List, str]:
        """获取单元下的课时列表"""
        for attempt in range(3):
            try:
                r = self.session.get(
                    f"{self.BASE_URL}/ajax/StudyStat.aspx",
                    params={"action": "scoLeaves", "cid": cid, "uid": uid, "unitidx": unit_idx, "classid": classid},
                    headers={"Referer": f"{self.BASE_URL}/2019/student/course_info.aspx?cid={cid}"},
                    timeout=15,
                )
                data = r.json()
                return True, data.get("info", []), "成功"
            except Exception as e:
                if attempt < 2:
                    time.sleep(1)
                    continue
                return False, [], str(e)

    def submit_progress(self, cid: str, uid: str, classid: str, scoid: str, accuracy: str) -> Tuple[bool, str]:
        """提交单个课时的进度"""
        ajax_url = f"{self.BASE_URL}/Ajax/SCO.aspx"
        referer = f"{self.BASE_URL}/Student/StudyCourse.aspx?cid={cid}&classid={classid}&sco={scoid}"
        for attempt in range(3):
            try:
                data = (
                    '{"cmi":{"completion_status":"completed","interactions":[],"launch_data":"","progress_measure":"1",'
                    f'"score":{{"scaled":"{accuracy}","raw":"100"}},"session_time":"0","success_status":"unknown",'
                    '"total_time":"0","mode":"normal"},"adl":{"data":[]},"cci":{"data":[],"service":{"dictionary":'
                    '{"headword":"","short_cuts":""},"new_words":[],"notes":[],"writing_marking":[],"record":'
                    '{"files":[]},"play":{"offline_media_id":"9999"}},"retry_count":"0","submit_time":""}}[INTERACTIONINFO]'
                )
                self.session.post(
                    ajax_url,
                    data={"action": "startsco160928", "cid": cid, "scoid": scoid, "uid": uid},
                    headers={"Referer": referer},
                    timeout=10,
                )
                r1 = self.session.post(
                    ajax_url,
                    data={"action": "setscoinfo", "cid": cid, "scoid": scoid, "uid": uid, "data": data, "isend": "False"},
                    headers={"Referer": referer},
                    timeout=10,
                )
                r2 = self.session.post(
                    ajax_url,
                    data={
                        "action": "savescoinfo160928", "cid": cid, "scoid": scoid, "uid": uid,
                        "progress": "100", "crate": accuracy, "status": "unknown", "cstatus": "completed", "trycount": "0",
                    },
                    headers={"Referer": referer},
                    timeout=10,
                )
                ok1 = r1.status_code == 200 and '"ret":0' in r1.text
                ok2 = r2.status_code == 200 and '"ret":0' in r2.text
                if ok1 or ok2:
                    return True, f"方式{'1' if ok1 else '2'}成功"
                return False, f"提交失败"
            except Exception as e:
                if attempt < 2:
                    time.sleep(1)
                    continue
                return False, f"提交异常: {e}"

    def simulate_time(self, cid: str, uid: str, scoid: str, seconds: int, callback=None, stop_event=None, speed: int = 1) -> Tuple[bool, str]:
        """模拟学习时长（speed 倍速：10=10倍速）"""
        ajax_url = f"{self.BASE_URL}/Ajax/SCO.aspx"
        common = {"uid": uid, "cid": cid, "scoid": scoid}
        headers = {"Referer": f"{self.BASE_URL}/student/StudyCourse.aspx"}
        real_total = max(seconds // speed, 1)
        heartbeat_interval = max(60 // speed, 1)
        try:
            # 启动 sco，获取 timelimitsec
            r = self.session.post(ajax_url, data={**common, "action": "startsco160928"}, headers=headers, timeout=10)
            start_data = r.json() if r.status_code == 200 else {}
            timelimitsec = start_data.get("timelitsec", seconds)

            # 获取 total_time
            r_info = self.session.get(
                f"{self.BASE_URL}/ajax/SCO.aspx",
                params={"action": "getscoinfo", "cid": cid, "uid": uid, "scoid": scoid},
                headers=headers, timeout=10,
            )
            from urllib.parse import unquote
            total_time = 0
            try:
                info_data = r_info.json()
                comment = unquote(info_data.get("comment", "{}"))
                cmi = json.loads(comment).get("cmi", {}) if comment.startswith("{") else {}
                total_time = int(cmi.get("total_time", 0) or 0)
            except: pass

            session_time = 0
            for t in range(1, real_total + 1):
                if stop_event and stop_event.is_set():
                    return True, "已停止（进度已保留）"
                time.sleep(1)
                session_time += 1 * speed
                total_time += 1 * speed
                if callback:
                    callback(t * speed, seconds)
                if t % heartbeat_interval == 0:
                    self.session.post(
                        ajax_url,
                        data={
                            "action": "keepsco_with_getticket_with_updatecmitime",
                            "uid": uid, "cid": cid, "scoid": scoid,
                            "session_time": session_time, "total_time": total_time,
                            "timelimitsec": timelimitsec, "endcaltime": "false",
                        },
                        headers=headers, timeout=10,
                    )
            self.session.post(
                ajax_url,
                data={**common, "action": "savescoinfo160928", "progress": "100", "crate": "0",
                      "status": "unknown", "cstatus": "completed", "trycount": "0"},
                headers=headers, timeout=10,
            )
            return True, "刷时长完成"
        except Exception as e:
            return False, f"刷时长异常: {e}"

    def get_task_list(self) -> Tuple[bool, List, str]:
        """获取班级任务列表（Chapter Test）"""
        try:
            r = self.session.post(
                f"{self.BASE_URL}/ajax/ClassTask.aspx",
                data={"action": "getList"},
                headers={
                    "Referer": f"{self.BASE_URL}/2019/student/index.aspx",
                    "X-Requested-With": "XMLHttpRequest",
                },
                timeout=15,
            )
            if r.status_code != 200:
                return False, [], f"请求失败: {r.status_code}"
            text = r.text.strip()
            if text.startswith("{"):
                result = r.json()
                if isinstance(result, list):
                    return True, result, "成功"
                elif isinstance(result, dict):
                    errcode = result.get("ret", result.get("code", 0))
                    if errcode == 0:
                        data_list = result.get("data", result.get("list", result.get("tasks", [])))
                        return True, data_list if isinstance(data_list, list) else [result], "成功"
                    return False, [], f"API错误: {result.get('mess', errcode)}"
            elif "prelogin" in text[:500].lower():
                return False, [], "未登录"
            return False, [], f"非JSON响应: {text[:200]}"
        except Exception as e:
            return False, [], f"获取任务异常: {e}"
